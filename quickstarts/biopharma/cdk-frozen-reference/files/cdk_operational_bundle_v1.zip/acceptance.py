"""Semantic acceptance for freshly recomputed fixed-input results, not just file hashes."""
import json
import math
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from rdkit import Chem

PROFILE = json.loads((Path(__file__).parent / "profile.json").read_text())


def compare_json(actual, expected, path="root"):
    if isinstance(expected, dict):
        if actual.keys() != expected.keys():
            raise AssertionError(f"JSON fields differ at {path}")
        for key in expected:
            compare_json(actual[key], expected[key], path + "." + key)
    elif isinstance(expected, list):
        if len(actual) != len(expected):
            raise AssertionError(f"JSON lengths differ at {path}")
        for i, (a, b) in enumerate(zip(actual, expected)):
            compare_json(a, b, path + str(i))
    elif isinstance(expected, float):
        if not math.isfinite(actual) or not math.isclose(
                actual, expected, rel_tol=PROFILE["numeric_relative_tolerance"],
                abs_tol=PROFILE["numeric_absolute_tolerance"]):
            raise AssertionError(f"JSON number differs at {path}: {actual} != {expected}")
    elif isinstance(expected, str):
        if not isinstance(actual, str) or actual.rstrip() != expected.rstrip():
            raise AssertionError(f"JSON text differs at {path}: {actual!r} != {expected!r}")
    elif actual != expected:
        raise AssertionError(f"JSON value differs at {path}: {actual} != {expected}")


def check(work, baseline):
    checks = []
    for name in ("assessment_scores", "assessment_independent_benchmark", "assessment_robustness", "ranking_summary"):
        relative = Path("results") / (name + ".json")
        expected = json.loads((baseline / relative).read_text())
        if name == "ranking_summary":
            # Clean source adds this caution; the pinned summary predates that annotation.
            expected["limitations"].append("No all-CDK selectivity claim.")
        compare_json(json.loads((work / relative).read_text()), expected)
        checks.append(name + "_recomputed_matches")
    for relative in ("results/assessment_rankings.csv", "results/solubility_qualified_predictions.csv",
                     "outputs/top100_candidates.csv"):
        a, b = pd.read_csv(work / relative), pd.read_csv(baseline / relative)
        pd.testing.assert_frame_equal(a, b, check_exact=False,
                                      rtol=PROFILE["numeric_relative_tolerance"],
                                      atol=PROFILE["numeric_absolute_tolerance"])
        checks.append(relative + "_all_fields_and_order_match")
    if (work / "outputs/top100_structures.smi").read_text() != (baseline / "outputs/top100_structures.smi").read_text():
        raise AssertionError("Native SMILES differ")
    # Sequential parsing avoids indexed-SDF CRLF seek behavior on older exports.
    with (work / "outputs/top100_structures.sdf").open("rb") as a, (baseline / "outputs/top100_structures.sdf").open("rb") as b:
        actual = list(Chem.ForwardSDMolSupplier(a, removeHs=False))
        expected = list(Chem.ForwardSDMolSupplier(b, removeHs=False))
    if len(actual) != 100 or len(expected) != 100 or any(m is None for m in actual + expected):
        raise AssertionError("Unreadable or incorrect native structures")
    for a, b in zip(actual, expected):
        if Chem.MolToSmiles(a) != Chem.MolToSmiles(b):
            raise AssertionError("Native structure identity differs")
        np.testing.assert_allclose(a.GetConformer().GetPositions(), b.GetConformer().GetPositions(), rtol=0, atol=1e-4)
    eligible = set(pd.read_csv(work / "data/library_qualified.csv").parent_id)
    if len(eligible) != 1100:
        raise AssertionError("Eligible parent count differs")
    for target in PROFILE["targets"]:
        for parent in eligible:
            path = work / "docking" / target / "ex1_s20261102" / parent
            result = json.loads((path / "result.json").read_text())
            if (result["status"] != "docked" or result["target"] != target or
                    result["parent_id"] != parent or not math.isfinite(result["score_kcal_mol"]) or
                    not (path / "rank1.sdf").is_file() or not (path / "poses.pdbqt").is_file()):
                raise AssertionError(f"Retained docking evidence invalid: {target}/{parent}")
    summary = json.loads((work / "results/ranking_summary.json").read_text())
    if summary["validated_leads"] != 0 or summary["experimentally_established_broad_3fold_selective"] != 0:
        raise AssertionError("Invalid lead-validation claim")
    result = {
        "status": "passed", "checks": checks, "primary_docking_pairs_reused": 6600,
        "predictions_recomputed": 1100, "native_structures_reexported": 100,
        "numeric_tolerances": {"rtol": 1e-10, "atol": 1e-10, "coordinate_atol_angstrom": 1e-4},
        "scope": "Fixed-input decision scoring, inference and ranking reproduced; docking and training retained",
        "annotation_policy": [
            "Trailing whitespace ignored in JSON text only",
            "Recomputed ranking must append exactly: No all-CDK selectivity claim.",
        ],
        "experimental_broad_threefold_selectivity": "unestablished", "CDK7_pose_validation": "failed",
    }
    (work.parent / "semantic_acceptance.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    check(Path(sys.argv[1]), Path(sys.argv[2]))
