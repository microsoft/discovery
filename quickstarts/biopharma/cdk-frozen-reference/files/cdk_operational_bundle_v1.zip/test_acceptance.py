"""Semantic comparison tests; require the profile's scientific dependencies."""
import unittest

from acceptance import compare_json


class ComparisonTests(unittest.TestCase):
    def test_trailing_annotation_whitespace_is_not_a_scientific_change(self):
        compare_json({"ranking": "fixed methodology"}, {"ranking": "fixed methodology \r\n"})

    def test_changed_text_rejected(self):
        with self.assertRaises(AssertionError):
            compare_json({"ranking": "changed methodology"}, {"ranking": "fixed methodology "})

    def test_changed_integer_rejected(self):
        with self.assertRaises(AssertionError):
            compare_json({"count": 99}, {"count": 100})

    def test_changed_float_rejected(self):
        with self.assertRaises(AssertionError):
            compare_json({"value": 0.6}, {"value": 0.7})

    def test_nonfinite_rejected(self):
        with self.assertRaises(AssertionError):
            compare_json({"value": float("nan")}, {"value": 0.7})

    def test_missing_caution_rejected(self):
        with self.assertRaises(AssertionError):
            compare_json({"limitations": []}, {"limitations": ["No all-CDK selectivity claim."]})

    def test_unexpected_caution_rejected(self):
        with self.assertRaises(AssertionError):
            compare_json({"limitations": ["No all-CDK selectivity claim.", "unreviewed"]},
                         {"limitations": ["No all-CDK selectivity claim."]})


if __name__ == "__main__":
    unittest.main()
