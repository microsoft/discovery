param(
    [ValidateSet('preflight','setup','run','resume')][string]$Action = 'preflight',
    [string]$Python = 'python',
    [string]$Snapshot = (Join-Path $PSScriptRoot 'cdk_non_md_deliverables.zip'),
    [string]$RunId = '',
    [switch]$ConsentInstall,
    [switch]$ApproveCompute
)
$ErrorActionPreference = 'Stop'
$argsList = @((Join-Path $PSScriptRoot 'workflow.py'), $Action, '--snapshot', $Snapshot)
if ($RunId) { $argsList += @('--run-id', $RunId) }
if ($ConsentInstall) { $argsList += '--consent-install' }
if ($ApproveCompute) { $argsList += '--approve-compute' }
& $Python @argsList
if ($LASTEXITCODE -ne 0) { throw "CDK workflow stopped with exit code $LASTEXITCODE; inspect the printed receipt/log path." }
