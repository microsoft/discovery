"""Portable frozen-data computation; never run scientific source in the original workspace."""
import argparse
import csv
import datetime as dt
import hashlib
import importlib.metadata
import io
import json
import os
from pathlib import Path, PurePosixPath
import platform
import re
import shutil
import stat
import subprocess
import sys
import time
import uuid
import zipfile

BUNDLE = Path(__file__).resolve().parent
if os.name == "nt" and not str(BUNDLE).startswith("\\\\?\\"):
    BUNDLE = Path("\\\\?\\" + str(BUNDLE))
PROFILE = json.loads((BUNDLE / "profile.json").read_text(encoding="utf-8"))
BASELINES = [
    "results/assessment_scores.json", "results/assessment_rankings.csv",
    "results/assessment_independent_benchmark.json", "results/assessment_robustness.json",
    "results/solubility_qualified_predictions.csv", "results/ranking_summary.json",
    "outputs/top100_candidates.csv", "outputs/top100_structures.sdf",
    "outputs/top100_structures.smi",
]


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def write(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def members_safe(infos):
    seen = set()
    for info in infos:
        name = info.orig_filename
        p = PurePosixPath(name)
        parts = name.rstrip("/").split("/")
        if (not name or name != info.filename or "\\" in name or p.is_absolute() or
                any(x in ("", ".", "..") or ":" in x or x.endswith((" ", ".")) for x in parts) or
                any(re.match(r"^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)", x, re.I) for x in parts) or
                stat.S_ISLNK(info.external_attr >> 16) or
                any(ord(c) < 32 for c in name) or name.casefold() in seen):
            raise ValueError(f"Unsafe or duplicate archive member: {name!r}")
        seen.add(name.casefold())


def check_snapshot(path):
    if path.is_symlink() or not path.is_file():
        raise FileNotFoundError(f"Expected regular snapshot file: {path}")
    if path.stat().st_size != PROFILE["snapshot_bytes"] or digest(path) != PROFILE["snapshot_sha256"]:
        raise ValueError("Incorrect or mutated snapshot; no extraction or model loading permitted")
    with zipfile.ZipFile(path) as archive:
        members_safe(archive.infolist())
        if len(archive.infolist()) != PROFILE["entries"]:
            raise ValueError("Unexpected archive member count")


def versions():
    actual, errors = {}, []
    if platform.python_version() != PROFILE["python"] or platform.architecture()[0] != PROFILE["architecture"]:
        errors.append("Require Python 3.13.14 64-bit; alternate runtime is unvalidated")
    for name, required in PROFILE["requirements"].items():
        try:
            actual[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            actual[name] = None
        if actual[name] != required:
            errors.append(f"{name}: required {required}, installed {actual[name]}")
    return actual, errors


def environment():
    env = os.environ.copy()
    for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "BLIS_NUM_THREADS"):
        env[key] = "1"
    env.update(CUDA_VISIBLE_DEVICES="-1", PYTHONHASHSEED="20261102",
               PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1",
               PYTHONPATH=str(BUNDLE / "offline_guard"))
    return env


def preflight(snapshot, destination):
    check_snapshot(snapshot)
    actual, errors = versions()
    probe = destination / (".write-probe-" + uuid.uuid4().hex)
    with probe.open("x", encoding="ascii") as stream:
        stream.write("write permission")
    probe.unlink()
    free = shutil.disk_usage(destination).free
    if free < PROFILE["free_space_guidance_bytes"]:
        errors.append("Less than configured 3 GB free-space safety allowance (not a measured minimum)")
    if not errors:
        result = subprocess.run(
            [sys.executable, "-c",
             "import numpy,scipy,pandas,sklearn,joblib,rdkit,meeko,gemmi,Bio,requests,markdown,bs4,openpyxl,PIL,threadpoolctl"],
            env=environment(), capture_output=True, text=True, timeout=120)
        if result.returncode:
            errors.append("Dependency import failed: " + result.stderr[-3000:])
    return dict(status="blocked" if errors else "ready", utc=now(), snapshot_sha256=PROFILE["snapshot_sha256"],
                python=platform.python_version(), executable=sys.executable, platform=platform.platform(),
                logical_cpus=os.cpu_count(), RAM_bytes=None, free_bytes=free,
                cpu_policy="one scientific stage at a time; one numerical thread; no GPU",
                versions=actual, errors=errors,
                app_activation="not tested by CLI", network="denied in replay subprocesses")


def extract(snapshot, work):
    if work.exists():
        raise FileExistsError("Extraction requires a new destination")
    work.mkdir()
    with zipfile.ZipFile(snapshot) as archive:
        members_safe(archive.infolist())
        for item in archive.infolist():
            path = work.joinpath(*PurePosixPath(item.filename).parts)
            path.parent.mkdir(parents=True, exist_ok=True)
            if item.is_dir():
                path.mkdir(exist_ok=True)
            else:
                with archive.open(item) as source, path.open("xb") as target:
                    shutil.copyfileobj(source, target)


def verify_payload(work):
    manifest = work / "outputs" / "artifact_manifest.csv"
    with manifest.open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    if len(rows) != PROFILE["payloads"]:
        raise ValueError("Wrong snapshot manifest count")
    seen = set()
    for row in rows:
        path = work.joinpath(*PurePosixPath(row["path"]).parts)
        if not path.resolve().is_relative_to(work.resolve()) or row["path"] in seen:
            raise ValueError("Invalid manifest path")
        seen.add(row["path"])
        if path.stat().st_size != int(row["bytes"]) or digest(path) != row["sha256"]:
            raise ValueError("Snapshot payload differs: " + row["path"])
    return len(rows)


def tree_hashes(work):
    result = {}
    for path in sorted(work.rglob("*")):
        if path.is_symlink():
            raise ValueError("Symlink in run tree")
        if path.is_file():
            result[path.relative_to(work).as_posix()] = digest(path)
    return result


def child(command, work, log):
    with log.open("w", encoding="utf-8") as stream:
        process = subprocess.Popen(command, cwd=str(work).removeprefix("\\\\?\\"), env=environment(),
                                   stdout=stream, stderr=subprocess.STDOUT)
        try:
            code = process.wait(timeout=PROFILE["stage_timeout_seconds"])
        except (subprocess.TimeoutExpired, KeyboardInterrupt):
            if os.name == "nt":
                subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"],
                               stdout=stream, stderr=subprocess.STDOUT, check=False)
            else:
                process.terminate()
            try:
                process.wait(timeout=15)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
            raise
    if code:
        raise RuntimeError(f"Stage failed with exit {code}; see {log}")


def setup(snapshot, consent):
    if not consent:
        raise PermissionError("Setup requires --consent-install; nothing installed")
    check_snapshot(snapshot)
    if platform.python_version() != PROFILE["python"]:
        raise ValueError("Install Python 3.13.14 separately; setup cannot substitute a runtime")
    envdir = BUNDLE / (".venv-" + uuid.uuid4().hex[:8])
    subprocess.run([sys.executable, "-m", "venv", str(envdir)], check=True)
    python = envdir / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    with zipfile.ZipFile(snapshot) as archive:
        requirement = envdir / "snapshot-requirements.txt"
        requirement.write_bytes(archive.read("requirements.txt"))
    subprocess.run([str(python), "-m", "pip", "install", "-r", str(requirement)], check=True)
    subprocess.run([str(python), "-m", "pip", "check"], check=True)
    print(json.dumps({"isolated_python": str(python), "next": "Use this interpreter for preflight/run",
                      "transitive_dependencies": "not fully locked; installation is networked and opt-in"}))


def run(snapshot, action, run_id, approved):
    if not approved:
        raise PermissionError("Computation requires --approve-compute")
    runs = BUNDLE / "runs"
    runs.mkdir(exist_ok=True)
    if run_id and not re.fullmatch(r"[A-Za-z0-9_-]{1,60}", run_id):
        raise ValueError("Run ID must be 1-60 letters, digits, underscore or hyphen")
    run_id = run_id or (dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:6])
    directory = runs / run_id
    if action == "resume":
        if not run_id or not directory.is_dir():
            raise FileNotFoundError("Resume requires an existing --run-id")
    else:
        directory.mkdir()
    statepath = directory / "receipt.json"
    state = json.loads(statepath.read_text()) if action == "resume" else {
        "profile": PROFILE["profile"], "run_id": run_id, "started_utc": now(),
        "snapshot_sha256": PROFILE["snapshot_sha256"], "stages": [],
        "recomputed": PROFILE["recomputed"], "retained": PROFILE["retained"],
        "scientific_gates": {"validated_broad_3fold_leads": 0, "CDK7_pose_validation": "failed"},
        "launcher_hashes": {p.name: digest(p) for p in (BUNDLE / "workflow.py", BUNDLE / "acceptance.py", BUNDLE / "profile.json")},
    }
    try:
        current_hashes = {p.name: digest(p) for p in (BUNDLE / "workflow.py", BUNDLE / "acceptance.py", BUNDLE / "profile.json")}
        if state["launcher_hashes"] != current_hashes:
            raise ValueError("Launcher/config changed since run; use a new run")
        readiness = preflight(snapshot, directory)
        write(directory / "preflight.json", readiness)
        if readiness["errors"]:
            raise RuntimeError("; ".join(readiness["errors"]))
        work = directory / "work"
        if action == "resume":
            expected = json.loads((directory / "checkpoint_hashes.json").read_text())
            if tree_hashes(work) != expected:
                raise ValueError("Run differs from last completed checkpoint; preserve it and create a new run")
        else:
            extract(snapshot, work)
            verify_payload(work)
            baseline = directory / "baseline"
            for name in BASELINES:
                dest = baseline / name
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(work / name, dest)
            write(directory / "checkpoint_hashes.json", tree_hashes(work))
        scripts = work / "scripts"
        stages = [
            ("decision_model", [sys.executable, str(scripts / "assessment.py"), "score"], "analysis"),
            ("solubility_inference", [sys.executable, str(scripts / "solubility.py"), "predict",
                                     "--input", "data/library_qualified.csv",
                                     "--output", "results/solubility_qualified_predictions.csv"], "analysis"),
            ("ranking", [sys.executable, str(scripts / "rank.py")], "analysis"),
            ("semantic_acceptance", [sys.executable, str(BUNDLE / "acceptance.py"),
                                    str(work), str(directory / "baseline")], "validation"),
            ("presentation", [sys.executable, str(scripts / "replay.py"), "--render"], "presentation"),
        ]
        completed = {s["name"] for s in state["stages"] if s["status"] == "passed"}
        state["status"] = "running"
        write(statepath, state)
        for name, command, category in stages:
            if name in completed:
                continue
            stage = {"name": name, "category": category, "start_utc": now(),
                     "command": command, "status": "running"}
            state["stages"].append(stage)
            write(statepath, state)
            t0 = time.perf_counter()
            try:
                child(command, work, directory / (name + ".log"))
            finally:
                stage["elapsed_wall_seconds"] = time.perf_counter() - t0
                stage["end_utc"] = now()
                write(statepath, state)
            stage["status"] = "passed"
            write(directory / "checkpoint_hashes.json", tree_hashes(work))
            write(statepath, state)
        state.update(status="completed", completed_utc=now(),
                     analysis_wall_seconds=sum(s["elapsed_wall_seconds"] for s in state["stages"]
                                               if s["category"] == "analysis" and s["status"] == "passed"),
                     timing_definition="Serial analysis subprocess elapsed, excludes setup/validation/presentation; not CPU time",
                     report_scope="Retained narrative rendered only after recomputed reference values pass semantic acceptance",
                     full_fresh_end_to_end=False, full_redocking=False, model_retrained=False,
                     app_activation="not tested by CLI")
        write(directory / "replay_artifact_hashes.json", tree_hashes(work))
        write(statepath, state)
        print(json.dumps({"status": state["status"], "receipt": str(statepath),
                          "analysis_wall_seconds": state["analysis_wall_seconds"],
                          "dashboard": str(work / "outputs/cdk_executive_dashboard.html")}))
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError, KeyboardInterrupt) as exc:
        state.update(status="failed", stopped_utc=now(), error=f"{type(exc).__name__}: {exc}")
        for stage in state["stages"]:
            if stage["status"] == "running":
                stage["status"] = "failed"
        write(statepath, state)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["preflight", "setup", "run", "resume"])
    parser.add_argument("--snapshot", type=Path, default=BUNDLE / PROFILE["snapshot_name"])
    parser.add_argument("--run-id")
    parser.add_argument("--consent-install", action="store_true")
    parser.add_argument("--approve-compute", action="store_true")
    parser.add_argument("--mode", choices=["frozen", "fresh"], default="frozen")
    args = parser.parse_args()
    if args.mode == "fresh":
        parser.error("Fresh-data mode is separately agent-led using Quick Start section 6; no automated fresh pipeline is claimed")
    lock = BUNDLE / ".workflow.lock"
    try:
        with lock.open("x", encoding="utf-8") as stream:
            json.dump({"pid": os.getpid(), "started_utc": now(), "action": args.action}, stream)
    except FileExistsError:
        parser.error("Another workflow or stale lock exists. Inspect exact PID before manually removing .workflow.lock")
    try:
        snapshot = args.snapshot.resolve()
        if args.action == "setup":
            setup(snapshot, args.consent_install)
        elif args.action == "preflight":
            report = preflight(snapshot, BUNDLE)
            target = BUNDLE / ("preflight-" + uuid.uuid4().hex[:8] + ".json")
            write(target, report)
            print(json.dumps({"status": report["status"], "receipt": str(target), "errors": report["errors"]}))
            if report["errors"]:
                raise SystemExit(2)
        else:
            run(snapshot, args.action, args.run_id, args.approve_compute)
    finally:
        lock.unlink()


if __name__ == "__main__":
    main()
