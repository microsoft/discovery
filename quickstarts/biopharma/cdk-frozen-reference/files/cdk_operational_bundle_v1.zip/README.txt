CDK OPERATIONAL HANDOFF v1

DEFAULT: frozen reference computation, NOT a new discovery campaign.
Use the comprehensive Quick-Start-BioPharma LeadGen.md supplied with this bundle.
Public repository/release URL and app activation are not yet validated.

RELEASE ASSETS
  cdk_operational_bundle_v1.zip and its .sha256/manifest/validation attachments
  cdk_non_md_deliverables.zip
    bytes: 168396900
    SHA256: bfc939735a574ccc2375ae9808e9242fb79efc545d5b3f314cc38e5d0cefa076
  pure_non_md_analysis_timing.md and .json (separate historical timing addenda)

Extract the operational bundle to a short new directory (absolute bundle path
below 180 characters recommended). Deep Windows paths can break Python sibling
imports despite extended-path data access; use a short local folder.
Put the exact named
snapshot ZIP next to workflow.py (do not extract it yourself). Open THAT directory
as the Discovery project. Do not select an original campaign or snapshot root.
The missing historical timed ZIP is NOT a dependency. Do not substitute the
original scientific ZIP containing historical out-of-scope files.

LOCAL COMMANDS (PowerShell; current directory is this bundle)
  python workflow.py preflight
  python workflow.py run --approve-compute
Equivalent app launch: follow "Execute in Discovery" in the comprehensive guide.
No custom agent registration is required. Select the existing Astra coordinator
and local command/file capability; use the existing investigator only if needed.
Model backend revision and investigator model are not pinned by this bundle.

SETUP ONLY AFTER CONSENT
  python workflow.py setup --consent-install
Setup creates a new bundle-local .venv-<id> using the existing Python 3.13.14 and installs the pinned
requirements from the verified snapshot; no system installs. It prints the exact
interpreter to use for preflight/run. No installation was necessary for the local
engineering check. Transitive requirements are not fully locked and packages may
require network access; a clean-machine installation has not been validated.
Another runtime/version is a hard preflight error, not a silent fallback.

WHAT ACTUALLY EXECUTES
1. Verify complete snapshot SHA256/size, reject unsafe ZIP paths/symlinks and
   collisions, verify dependency versions/imports, writable folder and free space.
2. Extract into a new runs/<id>/work tree and verify all 33442 payload hashes.
3. Execute unchanged assessment.py score: fixed encoded opportunity distributions,
   50000 draws and seed 20261102; NOT new literature assessment.
4. Execute unchanged solubility.py predict: actual inference for 1100 inputs
   with the saved model; NOT retraining or new measured solubility.
5. Execute scoped rank.py: properties/filters/clustering/ranking and native exports.
6. Compare recomputed decision JSON/CSV, all prediction/top100 fields and order,
   ranking summary, molecular identities/coordinates with preserved baselines.
   Numeric rtol/atol 1e-10, coordinate absolute tolerance 1e-4 angstrom.
   JSON text ignores trailing whitespace. The recomputed ranking must include
   the source-added caution "No all-CDK selectivity claim." beyond the archived
   limitations list. No other annotation or numeric differences are accepted.
   Reconcile 1100 identical parents x six retained receptors and native files.
7. Only on semantic success, regenerate HTML from retained report/visual assets.
   Narrative remains reference narrative, not new synthesis.
8. Write receipt, per-stage logs/timing and replay_artifact_hashes.json.

Training, assay/evidence curation, receptor preparation, 6600 primary docking pairs,
controls and scientific interpretation are reused. Nothing launches Vina, research,
training or molecular dynamics. Vina 1.2.7 is historical provenance, not a dependency
of this default. Do not describe this as a full new E2E discovery run.
The snapshot's outputs/artifact_manifest.csv inventories ORIGINAL payloads; use the
new run's replay_artifact_hashes.json for the modified computation tree.

RESOURCE / ERROR / RESUME CONTRACT
Stages run serially with one numerical thread and CUDA disabled. Do not run
independent scientific jobs alongside this workflow; the campaign ceiling remains
four total threads. Bundle lock prevents concurrent launch in this directory,
not jobs launched by other tools or other bundle copies.
A Python socket guard denies connections in replay subprocesses; it is not an
operating-system sandbox and does not isolate arbitrary native programs. No retry loop.
Each stage has a 1800-second safety timeout; timeout/error stops, logs and marks
the receipt failed. Only the exact owned child process/tree is terminated.
Available run output, checkpoint and evidence are retained on handled failure.
Forced process termination can leave an incomplete run without a final receipt
or checkpoint. Preserve that run and start a new one; do not claim completion.
  python workflow.py resume --run-id <printed-id> --approve-compute
Resume skips passed stages only when the entire last checkpoint still matches,
the original snapshot matches, and launcher/config hashes match. Partially
modified failed-stage trees are rejected; start a new run rather than overwrite.
An interrupted launcher can leave .workflow.lock: inspect its exact PID first.
Remove that single lock only after confirming the owning process is no longer
running. Never kill unrelated processes or delete a broad folder tree.

FRESH DATA AND FULL REDOCKING
Fresh data is the separately approved agent-led mode in Quick Start section 6.
workflow.py --mode fresh intentionally fails with an explicit unsupported-mode
message; no missing pipeline is disguised as a successful reference replay.
The source archive lacks every original fresh receptor-preparation component.
Full 6600-pair redocking is NOT automated by this launcher. It requires separate
authorization, Vina 1.2.7 provisioning and a fresh run/cached-result policy; do not
run batch.py over retained results and label cache hits new docking.

LIMITATIONS
Zero established broad threefold-selective leads; all top100 exploratory.
CDK7 native pose validation failed. Solubility is not complete ADME.
Historical pure non-MD active-analysis lower bound: 28799.199905 seconds; not a
replay estimate, not full E2E runtime. New receipts time this serial replay.
App activation, new-machine installation, publication/anonymous GitHub downloads
and end-to-end fresh discovery remain unverified. No new agents are registered.

TESTS
  python test_workflow.py
  python test_acceptance.py
Standard-library contract tests; the actual small fixed-analysis replay is a
separate check. Failed validation is not success, and hash checks are not inference.
Four lifecycle tests mock the scientific stages to check failure receipts,
checkpoint/config mutation rejection and completed-stage skipping. They do not
establish recovery from an interrupted real scientific subprocess.
Seven comparison tests require the scientific dependencies and check text
normalization plus rejection of changed numbers, nonfinite values and cautions.
See validation/engineering_validation.json and the sanitized reference receipts
for the exact tested scope. CLI results do not prove Discovery UI activation.

MAINTAINER PACKAGING
  python build_release.py --run-id <completed-reference-id> --output-dir <new-existing-directory>
Requires a completed five-stage reference run, matching launcher hashes, guide
and saved contract-test output. Refuses existing release files. Uses an explicit
allowlist, sanitizes private host paths, and verifies the new ZIP/manifest.
The scientific snapshot is always a separate asset, never nested in this ZIP.

CLEANUP
Close the browser. Preserve receipt/logs. Delete only a specific disposable
runs/<id> or .venv-<id> you created after confirming its processes have stopped.
No environments, runs or scientific snapshot are embedded in the small operational
ZIP. Ship the pinned non-MD snapshot separately, retaining its license notices.
