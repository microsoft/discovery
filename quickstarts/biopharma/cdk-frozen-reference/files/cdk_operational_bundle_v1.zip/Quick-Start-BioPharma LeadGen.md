# Quick Start — BioPharma CDK Target Selection and Lead Discovery

**Purpose:** Launch the BioPharma scenario from Discovery with **frozen-input reference computation as the default**: recompute decision-model draws, solubility predictions and integrated candidate ranking from the supplied snapshot, then deliver native exports and a dashboard. **Fresh-data discovery is a separate, explicitly approved mode** covering new evidence, qualification, docking and training; it is not exact reproduction.

**Reference:** The campaign executed on 2026-11-02. Recipe version 0.3 adds a deterministic operational launcher; the version 0.2 fresh-science prompt is preserved below. The default does real fixed-input computation, not only viewing, hashing or HTML rendering. It reuses original docking, preparation, evidence curation and fitted-model training; it is not a new end-to-end discovery run.

**Exclusions:** No molecular dynamics, GPU computation, paid scientific services, Discovery Engine, Bookshelves, unrelated-project data or private-data uploads. Default reproduction explicitly permits only the hash-pinned supplied snapshot. Fresh mode must retrieve its own evidence.

**Customer distribution:** This Quick Start is intended to accompany a public GitHub repository/release. Use the scenario ZIP attached to the matching release, not GitHub's automatically generated source-code ZIP. Archive contents are listed separately in **Appendix A**. No personal file handoff, internal collaboration-system access or author-specific filesystem path is required. An exact public repository/release URL has not been supplied; publication of the listed assets is a maintainer prerequisite, not a confirmed completed upload.

**Engineer entry point:** Start with **section 5, Execute in Discovery**. It contains the release assets, exact app launch instruction, approval/error/resume behavior and output locations. Sections 1–4 explain the configuration; section 6 is the separately approved fresh-science prompt, not the default launcher.

## 1. Recipe identity — required

| Field | Value |
|---|---|
| Scenario and observable outcome | Full scientific scenario: compare CDK target–indication opportunities, screen at least 1,000 parents across a CDK panel and prioritize 100 exploratory structures. Default executable mode: reproduce fixed-input decision scoring, solubility inference and ranking using the supplied evidence, docking and fitted model; export native structures, dashboard and receipts. Fresh scientific execution is separately approved and agent-led. |
| Audience / vertical | BioPharma discovery scientists, research leaders, startup/investment decision-makers and demo reviewers. |
| Delivery mode | Discovery app with hosted model access and local scientific computation. Microsoft Discovery service deployment is not part of this recipe. |
| Tested configuration / profile identifier | Default executable `cdk-frozen-reference-v1`, defined by bundled `profile.json`. Fresh mode: `biopharma-cdk-non-md-cpu4-v0.2`, a consolidated agent-led recipe, not an automated pipeline. Snapshot cutoff: 2026-11-02 UTC. |
| Maintainer / recipe version / validation | Publishing repository maintainers handle distribution/support. Recipe 0.3; fresh prompt remains 0.2. Historical artifacts validated 2026-11-02; operational validation is recorded separately in `validation/engineering_validation.json` in the operational release. App/new-machine reproduction and publication sign-off remain pending. |

## 2. Configuration matrix

The coordinating chat configuration is distinguished from unrecorded investigator settings.

| Component | Applicability | Configuration to record |
|---|---|---|
| Model | Core | **GPT-6 Astra**, model ID **`gpt-6-astra`**, used in the coordinating chat; OpenAI model accessed through the Discovery app's hosted model integration. Exact backend revision, temperature, top-p, context/output limits and model seed: Not recorded. Model ID is not an immutable version pin. |
| Agents | Core | Discovery scientific assistant for planning, coordination and delivery; CLIO investigation capability for sustained execution and artifact tracking. Two logical roles are evidenced, not a verified count of every participating session. Investigator/subagent model IDs, agent build versions and instruction hashes: Not recorded. Do not assume every delegated call used Astra. |
| Orchestration | Core | Default: preflight → safe extraction/hash verification → fixed decision scoring → model inference → ranking/native exports → semantic comparison → presentation → receipts/hashes. Serial one-thread stages. Fresh mode retains the historical stage mapping below, maximum four total scientific threads and 30-minute progress updates. |
| Execution policy | Core | Default frozen launcher: serial stages, one numerical thread, no GPU, 1,800-second timeout per stage, no automatic retry, explicit installation/computation approval and checkpoint-checked resume. Fresh historical campaign: maximum four scientific threads, no overall cutoff after approval; historical global retry/stage-timeout settings were not recorded. |
| Tools / APIs | Core | Public web search/fetch; ChEMBL compounds/assays; RCSB/wwPDB structures; AqSolDB solubility; KIBA and permitted public mappings; literature, clinical and competitive sources. PowerShell/Python, RDKit, Meeko, AutoDock Vina, pandas/NumPy/SciPy, scikit-learn/joblib and offline reporting/ZIP/hash tools. |
| Scientific versions | Core | Python 3.13.14, 64-bit AMD64; Python dependencies below. AutoDock Vina 1.2.7 is required for separately approved new docking, not default inference/ranking. No Vina binary or installed environment is bundled. |
| Reporting capabilities | Core | Evidence-grounded Markdown and offline HTML with embedded tables/charts/molecular depictions; native CSV/SDF/SMILES; manifest/checksum validation. Investigation and scientific-report capabilities were used; exact capability versions/hashes: Not recorded. |
| Azure Container Apps (ACA) | N/A | No ACA deployment, images, replicas, service region or secret store required. |
| Sample inputs | Core | Default: hash-pinned `cdk_non_md_deliverables.zip` with 1,100-parent library, prepared panel, native docking, trusted fitted model and evidence/assays. Fresh run: independently retrieved public inputs. The available earlier clean release is intentionally pinned; it is not the missing timed release. |

### 2.1 Agents, corresponding tools and capabilities

The reference workflow used a coordinating assistant and a persistent investigation session. The stage responsibilities below do **not** imply that separate target-selection, docking, ADME or reporting agents were created. Scientific packages are invoked through local execution; they are not assumed to be individually registered MCP tools.

| Agent / execution component | Corresponding tools or interfaces | Capabilities and responsibilities | Access / setup requirement |
|---|---|---|---|
| **Discovery scientific assistant — coordinator** | Hosted `gpt-6-astra`; `ask_user`; `clio-start`, `clio-wait`, `clio-steer`, `clio-status`, `clio-stop`; file inspection and local execution as needed | Clarify objectives; present the plan; obtain authorization; launch and steer the investigation; monitor progress; communicate blockers; check delivery artifacts and explain limitations | Discovery chat with Astra access, investigation connection, local workspace access and approval for scientific execution |
| **CLIO investigation session — execution agent** | Started/resumed through `clio-start`; progress/results through `clio-wait`; steering through `clio-steer`; status/stop through the corresponding controls. Uses the scientific execution stack below through its own available tools | Sustain the multi-stage campaign; gather evidence; coordinate dependent/parallel work; execute scripts; retain checkpoints and provenance; recover missing jobs; produce results and package | Verify the investigator itself has web retrieval, file and local-command access. Parent-tool availability does not prove child access. Exact historical investigator model and tool-permission manifest were not retained |
| **Local scientific worker processes — not LLM agents** | `powershell`, `read_powershell`, `stop_powershell`; isolated Python executable; Vina executable and Python libraries | Retrieve/curate data, prepare structures, run docking, train/predict solubility, compute ranking and export artifacts | Run-owned environment and writable folders; CPU-only; shared maximum of four scientific threads, including nested numerical-library threads |

**Agent count and identity:** One coordinating chat and one durable investigation lineage are evidenced. That investigation was resumed across interruptions; continuation IDs do not represent separate simultaneous scientific campaigns. A complete historical count of internal delegated sessions, their models and their permissions is not available. The recipe does not require users to create a suite of named specialist agents that did not exist in the recorded run.

### 2.2 Stage-to-tool capability mapping

This table maps work to the recorded execution stack and source artifacts. It describes scientific responsibilities within the investigation, not additional agent definitions.

| Stage / responsible component | Tools, packages and sources | Capability | Output / completion evidence |
|---|---|---|---|
| **Planning and orchestration — coordinator + investigator** | CLIO controls; user approval; session task tracking (`sql` where exposed); local process controls | Plan dependencies, enforce resource/data policy, checkpoint and resume work, provide 30-minute progress updates | Approved plan, campaign configuration, stage status and execution logs |
| **Target and competitive assessment — investigator** | Public web search/fetch; clinical/literature/company sources; `assessment.py`; NumPy/pandas | Compare biology, therapeutic window, clinical evidence, selectivity, differentiation, market and execution/IP; run uncertainty and sensitivity analyses | Source ledger, criterion scores, 50,000-draw ranking results, runner-up and reversal scenarios |
| **Compound and assay qualification — investigator + Python workers** | ChEMBL API/data; KIBA and permitted mappings; requests, pandas, RDKit; qualified-library/evidence and clearance scripts | Normalize parent identities; curate assay evidence; deduplicate; exclude known potent selected-target binders; distinguish controls from discoveries | `data/library_qualified.csv`, assay provenance, exclusion records and eligibility counts |
| **Receptor/ligand preparation — investigator + Python workers** | RCSB/wwPDB structures; Biopython, Gemmi, RDKit, Meeko; retained structure-preparation source and panel records | Prepare receptors/ligands and docking inputs; retain grids and coordinate provenance; perform native-pose checks | Prepared structures, `structures/panel.json`, preparation provenance and receptor-validation status |
| **Cross-CDK docking — local workers under investigator control** | AutoDock Vina 1.2.7; `engine.py`, `batch.py`; CPU scheduler | Dock identical eligible parents across the panel; save native scores/poses; recover missing-only jobs and assess controls/seed sensitivity | Native pose/log files and reconciled target-parent results; reference total 6,600 primary pairs |
| **Solubility modeling — investigator + Python workers** | AqSolDB; RDKit descriptors/fingerprints; NumPy/pandas/SciPy; scikit-learn/joblib; `solubility.py` | Prepare scaffold-separated data; fit/evaluate baseline and predictive model; estimate uncertainty and domain applicability | Training/split provenance, trusted model artifact, held-out metrics, prediction and applicability flags |
| **Integrated prioritization — investigator + Python workers** | RDKit, pandas; `rank.py`; docking, assay and solubility outputs | Apply physicochemical/PAINS flags; assess diversity; integrate measured evidence and predictions without claiming validated selectivity | Ranked tables, filter counts, 100 exploratory CSV/SDF/SMILES exports and explicit unmet gates |
| **Report and reproducibility delivery — investigator; coordinator checks handoff** | `scientific-report` guidance; Markdown/HTML rendering; RDKit depictions; standard-library CSV/JSON, `hashlib` and `zipfile`; package/replay scripts | Generate matching evidence-grounded reports; embed offline data/graphics; preserve native artifacts; validate links, identities, counts and hashes | Markdown report, offline dashboard, manifest, checksum, validation receipt and clean ZIP |

**Important capability boundaries:** Docking ranks hypotheses; it does not measure potency or establish cross-target affinity ratios. The ADME-related capability exercised here is **solubility prediction**, not a comprehensive ADME/toxicology platform. Patent assessment is preliminary, not legal clearance. Failed validation and out-of-domain predictions remain visible in the outputs.

### 2.3 Runtime tools, skills and readiness checks

| Capability layer | Reference interfaces | What to verify before launch |
|---|---|---|
| Investigation control | `clio-start`, `clio-wait`, `clio-steer`, `clio-status`, `clio-stop`; optional `clio-archive` | A connected investigation capability is available, a bounded objective can be launched, and its status/results can be retrieved. Resume existing lineage rather than duplicating active work |
| Research retrieval | `web_search`, `web_fetch`; requests-based public data retrieval | Required public sources are reachable and retrieved material can be recorded with provenance; no authenticated browser-session access is assumed |
| Workspace inspection/editing | `glob`, `rg`, `view`, `apply_patch` or supported equivalents exposed in that session | Read and write a run-owned location; preserve original sources; do not assume tool names remain identical across model/tool configurations |
| Local execution | `powershell`, `read_powershell`, `stop_powershell`, `list_powershell` | The isolated Python and Vina executables run; process IDs/logs can be tracked; only run-owned processes are stopped |
| Investigation guidance | `investigate` skill | The capability is available in the active skill catalog. It guides investigation; it is not itself a chemistry engine or an additional scientific dataset |
| Report guidance | `scientific-report` skill | The capability is available and can generate Markdown plus offline HTML using actual evidence. It does not install scientific dependencies |
| User approval and task state | `ask_user`; session `sql` where available | Installation/scope approvals and stage status are captured; neither tool replaces scientific validation |

Tool names above are the exposed interfaces from this session, not a separately exported, version-pinned plugin installation specification. Verify them in the recipient's runtime and in the investigator's context before launching. If missing, connect the appropriate reviewed capability through the app's supported GitHub URL, MCP server or local-folder flow. Record actual registration/version and permission details; do not treat a file on disk as proof of activation.

**Not required:** Discovery Engine, Bookshelves, ACA/HPC deployment, molecular-dynamics engines, GPU tools, browser automation, internal collaboration-system access or a personal handoff from the scenario author.

**Pinned Python requirements** — retained `requirements.txt`:

```text
numpy==2.4.3
scipy==1.17.1
pandas==2.2.3
scikit-learn==1.8.0
joblib==1.5.3
rdkit==2025.9.6
meeko==0.7.1
gemmi==0.7.5
biopython==1.86
requests==2.32.5
Markdown==3.10.2
beautifulsoup4==4.13.4
openpyxl==3.1.5
Pillow==12.1.1
```

**Scientific parameters:** 50,000 decision-model draws, seed 20261102; weights: biology 20%, therapeutic window 20%, clinical translation 15%, selective tractability 15%, differentiation 15%, commercial opportunity 10%, execution/IP 5%. Primary batch docking: seed 20261102, one CPU per Vina job, exhaustiveness 1, three poses, energy range $4\,\mathrm{kcal\,mol^{-1}}$, batch chunk size 50, maximum four workers. Other recorded seeds: 20261103 and 20261104. Low-exhaustiveness screening is exploratory, not an affinity measurement.

**Reference receptor panel:** CDK4/7SJ3, CDK6/2EUF, CDK2/1H1Q, CDK1/4Y72, CDK7/7B5O and CDK9/3BLR. Retain preparation, native-ligand and coordinate/grid provenance. CDK7 native-pose validation failed in the reference campaign.

## 3. System requirements

No hardware minima or cross-platform compatibility matrix was established. Recommendations are guidance, not benchmarks. “Actually tested” records the historical host/runtime, not a new survey of the recipient computer.

| Applies to | Requirement | Minimum | Recommended | Actually tested |
|---|---|---|---|---|
| App | OS and version | Not validated | Windows 11 matching the reference environment | `Windows-11-10.0.26300-SP0` in historical readiness record |
| App | CPU architecture | Not validated | x64/AMD64 | AMD64, 64-bit Python |
| App | CPU family / cores | Not validated | Capacity for up to four concurrent scientific threads; shared cap remains four | 22 logical CPUs reported; processor family and physical-core count Not recorded |
| App | RAM | Not validated | Size for data/model preparation and concurrent jobs; no numerical recommendation validated | Not recorded |
| App | GPU / VRAM | N/A | CPU-only; no GPU | No GPU scientific computation in scope |
| App | Free storage | Not validated | Short local workspace with room for raw data, environments, poses, logs and packaging copies; default launcher requires a 3 GB free-space safety allowance, not a measured minimum | Historical readiness recorded 436,270,391,296 free bytes. Default snapshot is 168,396,900 bytes compressed and 1,053,234,791 bytes uncompressed, before filesystem overhead; every new run extracts its own copy |
| App | Network | Not validated | Hosted-model and public scientific-source access during a fresh run | Public retrieval used; throughput/proxy/latency Not recorded |
| Services | General node pool: node count; SKU/size | N/A | N/A | Services not used |
| Services | General pool: vCPU/RAM/GPU per node; scale limits | N/A | N/A | Services not used |
| Services | SuperComputer Nodepool: node count; SKU/size | N/A | N/A | Services not used |
| Services | SuperComputer: vCPU/RAM/GPU per node; scale limits | N/A | N/A | Services not used |

**Bookshelf — Services:** N/A; the campaign explicitly excluded Bookshelves and former-project grounding.

| Field | Tested profile value |
|---|---|
| Source corpus | N/A for Bookshelf; public source records are retained directly with the campaign. |
| Index | N/A |
| Indexing recipe | N/A |
| Index-ready condition | N/A |

## 4. Prerequisites

- **Access:** Discovery app access and entitlement to select GPT-6 Astra; permission for local commands and isolated dependency installation; access to public sources. No Discovery service subscription, ACA quota or GPU allocation is required. Exact app build and authentication-provider configuration: Not recorded.
- **Capabilities:** Default frozen mode needs the existing scientific assistant and local command/file capability; investigation and public scientific retrieval are not required. Fresh mode additionally needs the investigation, retrieval and reporting capabilities in sections 2.1–2.3. CLIO is not Discovery Engine. Missing capabilities can be added through supported GitHub URL, MCP server or local-folder import flows; verify activation rather than assuming a file registers a capability.
- **Environment:** Python 3.13.14 x64 and the pinned requirements; use an isolated virtual environment for customer setup. Vina 1.2.7 is required only for separately approved docking, not default replay. Edge or another browser displays delivered HTML. PowerShell instructions below assume Windows.
- **Fresh-mode endpoints only:** ChEMBL: `https://www.ebi.ac.uk/chembl/api/data/`; structures: `https://files.rcsb.org/`; solubility metadata: `https://dataverse.harvard.edu/api/datasets/:persistentId/?persistentId=doi:10.7910/DVN/OVHAW8`; engine: `https://github.com/forlilab/AutoDock-Vina/releases/tag/v1.2.7`. The default scientific replay does not retrieve these sources. Hosted chat and opt-in dependency installation still require their own network access.
- **Authentication:** Use the app's supported sign-in/connection configuration for hosted-model access; do not put credentials in prompts or files. Public scientific endpoints were used without project secrets. Public GitHub release downloads require no internal organizational account; model access remains a separate prerequisite.
- **Data:** Fresh public retrieval for the fresh-run profile. Preserve ChEMBL CC BY-SA 3.0, KIBA CC BY 4.0, AqSolDB/wwPDB CC0 and source-specific notices. The unspecified-license DeepDTA mapping was not redistributed. Do not package copyrighted article full text or private data. Load joblib/pickle models only from trusted, hash-verified artifacts.

## 5. Setup — one reproducible reference path

### Execute in Discovery — default frozen-input computation

**Release assets:** Download `cdk_operational_bundle_v1.zip`, its checksum/validation attachments and **`cdk_non_md_deliverables.zip`** from the matching public release once published. No public release URL or anonymous download has yet been validated. The earlier clean snapshot is the actual available dependency: **168,396,900 bytes**, SHA256 **`bfc939735a574ccc2375ae9808e9242fb79efc545d5b3f314cc38e5d0cefa076`**, 33,442 payloads and 33,443 ZIP entries. Do not substitute the original scientific archive containing historical excluded work.

Extract the operational bundle to a **short new directory**, for example `C:\CDK-demo` if permitted, rather than a deeply nested project or synchronized folder. Keep the absolute bundle path below 180 characters: Python sibling-module imports can fail beyond the Windows path limit even when extended-path data access works. Put the **unextracted snapshot ZIP beside `workflow.py`, `profile.json` and `launch.ps1`**. Open that directory as the Discovery project, not the original campaign or an extracted scientific snapshot. Select **GPT-6 Astra (`gpt-6-astra`)**, enable the existing local command/file capability and, if needed, the existing investigation connection. No new agent definitions or registration are required; file presence is not runtime activation.

**One copy/paste launch instruction:**

```text
Use this open project as the CDK operational bundle root. Run the default
cdk-frozen-reference-v1 profile, not fresh discovery. Confirm workflow.py,
profile.json and cdk_non_md_deliverables.zip are present. Select the existing
local execution capability; do not create agents or retrieve scientific data.
Run: python workflow.py preflight
If preflight reports dependency/runtime errors, stop and show the receipt.
Do not install anything without my separate consent. If ready, I authorize
the bounded fixed-input computation:
python workflow.py run --approve-compute
Use one scientific stage at a time; do not launch other scientific jobs.
Report the run receipt, semantic acceptance, stage logs and dashboard path.
Clearly separate recomputed decision scoring, inference and ranking from
reused docking, training, evidence and report narrative. Do not call this
a new end-to-end discovery run or claim experimental selectivity.
```

**Direct equivalent (project root):**

```powershell
python workflow.py preflight
python workflow.py run --approve-compute
```

`launch.ps1 -Action preflight` and `launch.ps1 -Action run -ApproveCompute` are equivalent wrappers. If dependencies are missing, the user may separately authorize `python workflow.py setup --consent-install`. This creates a new `.venv-<id>` and prints its exact interpreter; use that interpreter for subsequent commands. Setup never changes system Python. Transitive packages are not fully locked; clean-machine installation has not been validated. Python/version mismatch is a blocker, not permission to silently substitute versions.

| Stage | Actual operation and output | Acceptance / boundary |
|---|---|---|
| Preflight and isolation | Exact ZIP hash/size; safe member paths; Python/dependency versions and imports; write/free-space checks; new `runs/<id>/work` extraction | Reject mutation, traversal, symlinks, case collisions and invalid inputs. Verify 33,442 payloads before loading the trusted saved model. Configured 3 GB free-space allowance is a safety margin, not a measured minimum. |
| Decision computation | `assessment.py score`; 50,000 seeded draws from fixed encoded opportunity distributions | Compare decision JSON/CSV to retained baseline; no new literature search or re-scoring of evidence. |
| Solubility inference | `solubility.py predict` for all 1,100 qualified parents | Compare predictions/status/domain fields; saved model reused, no retraining. |
| Integrated ranking | `rank.py`; recompute properties, filters, clustering, ordering and CSV/SDF/SMILES exports | Compare all top100 CSV fields/order, ranking summary, molecular identities and coordinates. |
| Scientific acceptance | Semantic comparisons and reconciliation of 6,600 retained primary pairs | Numeric relative/absolute tolerance `1e-10`; coordinate absolute tolerance `1e-4` angstrom. Zero validated broad-threefold leads and failed CDK7 gate remain explicit. |
| Presentation and delivery | Render retained Markdown/visuals only after semantic success; write receipt, logs and output hashes | Report narrative is reused, not new synthesis. `replay_artifact_hashes.json` inventories the new tree; its historical `outputs/artifact_manifest.csv` still describes original snapshot files. |

**Annotation comparison:** JSON text ignores trailing whitespace. The cleaned ranking source also adds the caution “No all-CDK selectivity claim.”, which is absent from the archived summary. Acceptance requires that exact added caution and otherwise compares the full summary; numeric tolerances and candidate/structure comparisons are unchanged. The replay does not silently discard changed scientific findings.

**Approval/error/resume contract:** One serial scientific stage, one numerical thread, no GPU. A Python socket guard blocks network connections in replay subprocesses; this is not an operating-system sandbox or a guarantee about arbitrary native programs. Do not run independent scientific work alongside it. Each stage has a 1,800-second safety timeout, no automatic retry. Handled errors stop and persist `runs/<id>/receipt.json` plus available logs. Forced process termination can leave an incomplete run without a final receipt/checkpoint; preserve it and create a new run. `python workflow.py resume --run-id <printed-id> --approve-compute` skips successful stages only if the entire saved checkpoint and launcher/config hashes match. Partially modified failed-stage trees are rejected; start a new run instead of overwriting. A bundle lock prevents concurrent launch in that directory, not arbitrary external jobs. Inspect the exact lock PID before removing a stale lock.

**Outputs:** `runs/<id>/preflight.json`, `receipt.json`, individual stage `.log` files, `semantic_acceptance.json`, `checkpoint_hashes.json`, `replay_artifact_hashes.json`, and `work/outputs/` native exports/dashboard. The receipt records measured per-stage wall-clock intervals and serial analysis elapsed separately from setup, validation and presentation. No new science-data ZIP is fabricated: the small operational ZIP and pinned snapshot together form the portable distribution.

**Local engineering evidence:** The frozen computation reproduced the decision results, 1,100 solubility predictions and 100 native candidate exports within the stated comparisons, with all 6,600 docking pairs retained rather than recalculated. Fourteen launcher-contract tests and seven semantic-comparison tests passed. Presentation initially hit a Windows long-path import failure; the owned run directory was shortened and presentation resumed from the unchanged scientific checkpoint. The release preserves that failure and recovery in its validation records. This is not an uninterrupted clean-machine or Discovery-UI run.

**Remaining scope boundaries:** Full 6,600-pair redocking is an explicit separately approved extension, not a launcher switch or a cache hit labeled as new docking. Default training and all preparation/evidence retrieval are retained. The source archive lacks some fresh receptor-preparation components. `--mode fresh` deliberately stops with a clear message directing users to the separate agent-led prompt; it does not pretend an automated fresh pipeline exists. CLI tests cannot establish Discovery activation, new-machine installation or a clean-start full E2E run.

### Separately approved mode: fresh-data discovery

**Prepare the reference source:** Use the verified available clean snapshot above for source inspection, retaining its `README.txt` and `LICENSE.txt`. Keep it unchanged. For fresh discovery, copy only reviewed source and requirements into a separate authorized working directory, not reference data, docking results or fitted models. The following manual/agent-led sequence is distinct from the tested frozen launcher; missing preparation capabilities must be resolved explicitly.

1. **Select profile:** Open a fresh Discovery app project/session and select **GPT-6 Astra (`gpt-6-astra`)**. Record app/model/tool/agent versions. Use a short local workspace and a new session output folder; do not inherit research datasets or project memory. Reference code may be inspected for methods, but results must use the declared inputs.
2. **Install/provision after approval:** Use the reviewed `scripts/` source and pinned `requirements.txt` from the verified release archive. Keep the extracted reference copy unchanged. Create an isolated virtual environment in the new run's working directory; do not install into system Python. Services/ACA: N/A.

```powershell
python --version
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m pip check
```

Confirm Python 3.13.14 before proceeding. Another version is an unvalidated profile. These are setup instructions, not commands rerun during this documentation update.

3. **Deploy/configure:** Use the agent/tool mapping and readiness checks in sections 2.1–2.3. Confirm investigation, retrieval and local scientific tools in both the coordinating chat and investigation context. Configure the agent to invoke the isolated Python executable. Record actual agent models, tool permissions and capability versions where exposed. Set the following in every worker-launch environment; shell settings may not persist between tool calls:

```powershell
$env:OMP_NUM_THREADS = '1'
$env:OPENBLAS_NUM_THREADS = '1'
$env:MKL_NUM_THREADS = '1'
$env:NUMEXPR_NUM_THREADS = '1'
$env:CUDA_VISIBLE_DEVICES = '-1'
.\.venv\Scripts\python.exe scripts\engine.py
.\tools\vina.exe --version
```

Also limit the scheduler to four simultaneous scientific threads across all jobs. `engine.py` retrieves Vina 1.2.7 into run-local `tools`; verify release/version and retain URL/hash provenance. No containers are deployed.

4. **Load data:** Run the section 6 prompt. Obtain the plan/capability inventory and approve execution/installations before retrieval and long computation. The agent retrieves evidence, assays, structures and solubility data, records cutoff/licenses/hashes and prepares the library/panel. Do not run every historical script indiscriminately: the original workspace contains retired workflows outside this recipe.
5. **Verify readiness and execute:** Check imports, `pip check`, Vina version, source access, writable output paths, CPU limits, library eligibility and native-pose docking pilots. Expose failures. Continue the non-MD campaign after approval, with missing-only recovery/checkpoints and 30-minute progress updates. Apply section 6 acceptance criteria before release.

**Execution-source references:** `assessment.py` for evidence/decision modeling; `qualified_library.py`, `qualified_evidence.py` and clearance scripts for library/assays; receptor preparation and native-pose records; `batch.py` for docking; `solubility.py` for training/prediction; `rank.py` for integration. The campaign was agent-orchestrated across stages, not delivered as a verified one-command fresh-run launcher.

**Recorded docking invocation after inputs/receptors are ready**, in a separately authorized scientific working copy:

```powershell
.\.venv\Scripts\python.exe scripts\batch.py --input data/library_qualified.csv --targets CDK4 CDK6 CDK2 CDK1 CDK7 CDK9 --workers 4 --chunk 50 --seed 20261102
```

Successful jobs are cached. This command alone does not assess targets, qualify the library, train models or report results; existing cache hits are not proof of fresh computation.

### Secondary path: review supplied results without computation

Use the same **`cdk_non_md_deliverables.zip`** snapshot as the default launcher. Its expected size, SHA256 and counts are listed at the start of section 5; no second scientific archive is needed.

```powershell
Get-FileHash -LiteralPath '.\cdk_non_md_deliverables.zip' -Algorithm SHA256
```

Extract the full archive into a new short path and preserve directories. Open `outputs/cdk_executive_dashboard.html` in Edge or read `outputs/cdk_campaign_report.md`. No Discovery/model setup is required just to view existing files.

From the extracted root, `python scripts/replay.py --verify` checks hashes/counts using the standard library. With packaged requirements installed, `python scripts/replay.py --render` regenerates HTML only. Verify before rendering, which can change hashes. Neither command reruns science. Do not assume `--demo` or other options from the original archive exist in the clean package.

**Archived prompt:** Root `WORKFLOW_PROMPT.txt` has no molecular-dynamics requirement, but includes packaging-only delivery instructions. Do not launch fresh science with it unchanged; use the consolidated fresh-run prompt below.

## 6. Fixed prompt + matching output

**Binding for fresh mode only:** Profile `biopharma-cdk-non-md-cpu4-v0.2`, coordinating model `gpt-6-astra`, prompt version 0.2. The default frozen-mode launch instruction is in section 5. This fresh prompt is a consolidation, not a verbatim transcript or independently benchmarked monolithic execution. Use new public retrieval and record its cutoff; fresh sources can change recommendations and identities.

**Required agent configuration:** Retain the active Discovery scientific-assistant instructions, enforce the CPU/data policy below, and export available agent/model/tool versions with the run. Historical instruction hashes and investigator model settings are not available; full configuration pinning remains a publication gap.

**Exact predefined prompt**

```text
Run the BioPharma CDK target-selection and lead-discovery scenario in a fresh
Discovery app session. Use public sources retrieved for this run, not prior
project research data, memory or Bookshelves. Do not use Discovery Engine,
paid scientific services, private-data uploads, GPU computation or molecular
dynamics. Use isolated dependencies and at most four concurrent scientific
CPU threads across the entire campaign.

Before executing, show the plan, available agents/tools, input sources,
resource controls and output locations. Obtain approval for the plan and any
installations. Then work autonomously until the non-MD scope is complete or
a concrete blocker requires input. Provide a factual progress update every
30 minutes. Checkpoint work and resume missing jobs without duplicating them.

1. Assess human CDK target-indication-biomarker opportunities using biological,
clinical, safety, competitive and commercial evidence. Weight causal biology
0.20, therapeutic window 0.20, clinical translation 0.15, selective chemical
tractability 0.15, differentiation 0.15, commercial opportunity 0.10 and
execution/IP 0.05. Use 50,000 uncertainty draws with seed 20261102. Document
score assumptions, dependencies, sensitivity scenarios, evidence gaps,
runner-up and reversal criteria. Rank-winning frequencies are not calibrated
approval or investment-success probabilities. Do not predetermine the winner.

2. Curate at least 1,000 unique eligible parent compounds; aim for 1,100.
Use documented CDK inhibitors, broader kinase inhibitors and approved or
investigational drugs, distinguishing those classes. Do not imply that every
entry is a pan-CDK inhibitor or approved drug. Record structures, source
identifiers, assay type/units, licenses, retrieval times and exclusions.
Exclude discovery compounds with reported selected-target Kd, Ki or IC50
at or below $100\,\mathrm{nM}$; retain assay distinctions. Keep positive
controls separate. Missing activity is unknown, not inactive.

3. Prepare experimental receptors and validate native-ligand redocking.
For a CDK4 decision, the reference panel is CDK4, CDK6, CDK2, CDK1, CDK7 and
CDK9. If another CDK wins, justify the revised target/counter-target panel.
Dock the same eligible parents against every panel member. Record structures,
grids, preparation, engine version, commands, seeds, native poses and failures.
The reference primary screen uses Vina 1.2.7, seed 20261102, exhaustiveness 1,
three poses, energy range $4\,\mathrm{kcal\,mol^{-1}}$, one CPU per job and
at most four total workers. Treat this as low-exhaustiveness exploratory
screening; assess controls and repeated-seed sensitivity where feasible.
Explicitly flag failed receptor validation.

4. Seek evidence for at least $3\times$ cross-CDK selectivity using comparable
experimental assays. Raw cross-protein docking-score differences do not
establish affinity ratios. If selectivity remains unproven, retain it as an
unmet experimental gate rather than claiming selective leads.

5. Fit a predictive aqueous-solubility baseline and descriptor/fingerprint
model to licensed public measurements. Use scaffold-separated training,
calibration and held-out testing; reference seeds 20261102 and 20261103.
Record endpoint/units, assay and pH heterogeneity, deduplication, model,
split assignments, metrics, uncertainty and applicability domain. Clearly flag
unsupported charged/salt inputs and out-of-domain predictions. Solubility
prediction is not a full ADME assessment.

6. Prioritize 100 diverse structures using docking, measured assay evidence,
physicochemical filters, PAINS/reactivity alerts, pose plausibility and
solubility/domain flags. Retain pass/fail/unknown flags and all filter counts.
Export CSV, SDF and SMILES with stable identities and valid coordinates where
available. If fewer than 100 satisfy all gates, separate the qualifying set
from an exploratory top-100 list; do not silently relax the gates.

7. Deliver a comprehensive Markdown report and matching executive-friendly
offline HTML dashboard, beginning with the title and executive summary rather
than an opening "At a glance" section. Embed data tables, labeled charts and
faithful molecule depictions or explicit fallbacks. Include methods, evidence,
business/science tradeoffs, uncertainties, failures, sources and limitations.
Use no remote scripts, fonts or runtime data fetches.

8. Produce a reproducible ZIP with licensed data, provenance, source scripts,
pinned requirements, native poses, model/splits, candidate exports, the final
non-MD workflow prompt, SHA256 manifest and validation receipt. Exclude all
molecular-dynamics artifacts, installed environments and prior ZIPs.
Check hashes, safe archive paths, counts, molecular identities, local links
and report agreement. Preserve original artifacts rather than overwriting them.

9. Record wall-clock start/end intervals for each analysis stage from the
outset. Report pure non-MD analysis elapsed time separately from setup,
presentation and packaging. Merge overlapping active intervals instead of
summing concurrent jobs. Distinguish wall time from CPU time; label missing
intervals and lower bounds. Do not claim a complete timing total if the logs
cannot support it.
```

**Matching output — observed reference results**, not guaranteed values for new retrieval:

```text
Conditional target recommendation: CDK4
Indication: HR-positive/HER2-negative metastatic breast cancer after CDK4/6 treatment
Enrichment hypothesis: functional RB1 retention; not a validated companion diagnostic
Modeled rank-winning frequency: 68.538% of 50,000 draws
Principal alternative: CDK2, particularly ovarian opportunities
Eligible discovery parents: 1,100
Panel: CDK1, CDK2, CDK4, CDK6, CDK7, CDK9
Primary target-parent docking results: 6,600; no missing pairs in final reconciliation
Exported exploratory structures: 100 across 100 clusters
Physicochemical gate passed: 93/100; PAINS filter passed: 97/100
Within solubility applicability domain: 25/100
Configured solubility gate passed: 4/100
Established broad threefold-selective leads: 0
CDK7 native-pose validation: failed

outputs/cdk_campaign_report.md
outputs/cdk_executive_dashboard.html
outputs/top100_candidates.csv
outputs/top100_structures.sdf
outputs/top100_structures.smi
outputs/artifact_manifest.csv
WORKFLOW_PROMPT.txt
```

**Reference solubility results:** held-out test size 889; RMSE $1.088$ and MAE $0.770$ in log-molar units; $R^2=0.802$; nominal 90% interval coverage 86.05%, half-width $1.527$ log-solubility units. These are historical measured model-performance results, not fresh-run acceptance guarantees.

| Acceptance | Check |
|---|---|
| Required format / artifacts | Matching Markdown/offline HTML; CSV and valid SDF/SMILES; sources/assay evidence, receptor/pose provenance, decision model, solubility model/data/splits, scripts and pinned requirements; prompt, timing records, ZIP, manifest and checksums. Docking units: $\mathrm{kcal\,mol^{-1}}$; solubility endpoint: $\log_{10}(S/(\mathrm{mol\,L^{-1}}))$. |
| Exact checks | At least 1,000 unique eligible discovery parents, identical parent set across the declared panel, no unexplained missing/failed pairs, 100 exported exploratory structures or explicit shortfall, no known-potent discovery contamination within documented exclusion coverage, correct identities and payload hashes, no MD artifacts. For the supplied reference package only: 1,100 parents, six targets, 6,600 primary results and 100 exports. |
| Approximate / domain checks | Assess receptor redocking, control discrimination, docking sensitivity, assay comparability, held-out solubility error/calibration and applicability. Declare scientific validation thresholds before accepting new results; historical comprehensive threshold configuration is not fully captured here. Preserve CDK7's failed reference validation. Do not invent tolerances or infer potency/selectivity from scores. |
| Pass condition | Computational-delivery checks pass and all unmet scientific gates remain explicit. Scientific lead validation is separate: comparable experimental evidence is required for $\geq3\times$ selectivity. The reference campaign passed computational delivery, not this experimental gate. New-run reviewer/owner sign-off is required. |

**Reproducibility boundary:** The original archive had a successful extracted computational replay. The clean/timed archive retained non-MD scientific payloads and passed its recorded hash/count/presentation checks; that is not a separate full scientific rerun of the timed archive. Fresh evidence can change rankings and identities even with fixed numerical seeds.

## 7. Expected runtime

No measured cold/warm benchmark exists for the consolidated version 0.2 prompt. Do not label the observed analysis lower bound as a complete run-time estimate.

| Stage | Measured / Estimated | First response (optional) | Completion duration / range, with units | Conditions / observations / runs |
|---|---|---|---|---|
| One-time install/provision/setup | Not separately measured | Not recorded | Not recorded | Local isolated setup; no service provisioning. A setup-only benchmark was not retained. |
| One-time data loading/indexing | Retrieval not separately measured; indexing N/A | N/A | Not recorded | Fresh public retrieval; no Bookshelf index. Network/load/cache conditions Not recorded. |
| Cold-start prompt run | Not measured for consolidated prompt | Not recorded | Complete non-MD end-to-end duration unknown | Historical campaign is one execution with continuations, not a controlled cold benchmark. Model/backend and agent settings not fully pinned. |
| Warm prompt run | Not measured | Not recorded | Not recorded | Cached missing-only recovery occurred, but is not a controlled warm-run benchmark. |
| Default frozen computation: analysis subprocesses only | Measured on existing host | N/A | 92.755 seconds across decision scoring, inference and ranking | Excludes extraction, repeated full-tree hash/checkpoint work, semantic validation, presentation and recovery. File operations dominated observed elapsed time on the deeply nested synchronized workspace; this is not a total replay-duration estimate. |
| Recorded active non-MD analysis | Measured conservative lower bound | N/A | **7h 59m 59.2s, approximately 8 hours** | 2026-11-02; 208 timed records merged into eight intervals; overlap counted once; CPU-only, maximum four scientific threads |
| Solubility training workflow | Measured | N/A | 71.071370 seconds; fit portion 26.857726 seconds | Fit is nested within the workflow, not additive. Timing audit uses a conservative contained interval for the combined lower bound. |
| Initial clean repackaging | Measured | N/A | 24m 03.459833s | Packaging cleanup, retries and verification only; not scientific analysis |
| Later timing amendment | Measured | N/A | 40.052014 seconds | Packaging amendment only; not scientific analysis |

**Interpretation:** The approximately eight-hour lower bound excludes MD, report presentation and packaging; untimed literature/decision work, preparation and ranking prevent a complete pure-analysis total. It is neither CPU time nor a forecast of another run. Some scientific work overlapped excluded work; subtracting an MD duration from total elapsed time is invalid. The earlier 14h 23m overall campaign duration includes excluded work and must not be presented as non-MD analysis time.

The corrected `pure_non_md_analysis_timing.md` and `.json` are separate addenda, not embedded in the unchanged timed ZIP. A new run should capture all interval boundaries and separate setup, analysis, reporting and packaging from the outset.

## 8. Troubleshooting, cleanup and extensions

- **Model/agent unavailable:** Confirm Astra and required investigation, retrieval and local-compute capabilities in the active session. Record access/configuration limitations; do not silently substitute a model or claim a missing connection is installed.
- **Public retrieval failure:** Record URL, status and timestamp. Use retained inputs only under a separately declared snapshot-reproduction profile; do not pass cached sources off as fresh evidence.
- **Dependency or engine failure:** Check the isolated interpreter, `pip check`, import errors and Vina version/provenance. Capture failures before changing versions. Do not install retired simulation dependencies or run the historical all-workflow bootstrap.
- **Interrupted execution or request-size failure:** The campaign encountered oversized investigation requests. Preserve checkpoints, confirm existing process/job identities and resume missing-only work; do not start a duplicate campaign or kill unrelated processes.
- **Docking or selectivity failure:** Retain failed receptor validation and missing assay evidence. CDK7 failed native-pose validation in the reference. No validated broad-selectivity leads were established; report this rather than changing thresholds to repair the conclusion.
- **Archive/path problems:** Verify expected SHA256 and extract to a short new path. Historical Windows long-path handling required fixes. Keep full folder layout; do not move HTML alone. Verify pristine payload before presentation-only rendering. Report problems through the publishing repository's support channel with release identifier, OS/Python versions and sanitized error output; never include secrets.
- **Presentation versions:** The pinned snapshot retains its original opening “At a glance” section. The fresh-mode prompt requests the revised presentation; default replay retains the reference narrative. The corrected timing addenda are separate release files, not modifications to the immutable snapshot.
- **Cleanup:** Stop only verified run-owned processes; retain logs/checkpoints and evidence according to project policy. Remove only explicitly identified temporary files, run-owned virtual environments or disposable extracted copies. No ACA or HPC resources are created. Hosted model access remains subject to account terms; no cost total was measured.
- **Scientific extensions:** Additional experimental assays, higher-effort docking or other stages require separate scope/budget. Solubility is not complete ADME, docking is not measured affinity, functional RB1 enrichment is a hypothesis, and preliminary patent assessment is not freedom to operate.

## 9. Publication checklist

- [x] Scientific scenario, maintainer responsibility, coordinating Astra model, logical agent roles, CPU policy and final non-MD scope documented.
- [x] Agent-to-tool mapping, stage-specific capabilities, execution boundaries and runtime readiness checks documented without inventing separate specialist agents.
- [x] Historical software versions, input provenance, outputs, scientific limitations and acceptance checks documented.
- [x] Consolidated runnable prompt included and distinguished from the archived packaging prompt.
- [x] Measured timing, lower-bound coverage and unmeasured cold/warm/setup durations separated.
- [x] Services/ACA/Bookshelf fields marked N/A; unknown settings and hardware minima not invented.
- [x] Frozen launcher, explicit approval/error/resume behavior, semantic comparisons, source/configuration, local execution evidence and operational ZIP inventory supplied.
- [ ] Record app build, investigator/subagent model revisions, generation settings and versioned agent/tool instructions for a fully pinned new deployment.
- [ ] Reproduce the consolidated fresh-run recipe on the intended recipient environment and record setup/first-response/completion timing.
- [ ] Publish the named scenario ZIP, matching checksum/validation attachments and separate timing correction in the public GitHub release; confirm anonymous download access and add the exact release link to the repository README.
- [ ] Obtain maintainer validation/publication sign-off. Historical computational delivery is not experimental lead validation.

**Evidence references:** Package `campaign.json`, `environment.json`, `README.txt`, retained scientific source, manifest and release receipts. Historical host-readiness metadata informed the tested-environment table but is not a required customer input or a claim that the original workspace is bundled.

## Appendix A. Files in the scenario ZIP

This inventory describes the pinned **`cdk_non_md_deliverables.zip`** with the SHA256 in section 5. All paths below are relative to its extracted root. It lists entry points and important scientific artifacts; **`outputs/artifact_manifest.csv` is the complete per-file inventory**, including hashes, sizes and provenance for 33,442 payload files. The manifest itself is the additional archive entry, giving 33,443 entries in total. The historical timed variant is not required.

### A.1 Start here: documentation, configuration and deliverables

| File in ZIP | Purpose |
|---|---|
| `README.txt` | Package scope, offline viewing, verification/replay instructions, rights and portability notes |
| `LICENSE.txt` | Package licensing/attribution information; retain upstream notices |
| `WORKFLOW_PROMPT.txt` | Archived non-MD scope and packaging instructions; use section 6 of this Quick Start for a fresh campaign |
| `campaign.json` | Scoped campaign configuration and recorded parameters |
| `environment.json` | Recorded runtime/dependency metadata |
| `requirements.txt` | Pinned Python requirements; environments themselves are not bundled |
| `outputs/cdk_executive_dashboard.html` | Offline executive report/dashboard |
| `outputs/cdk_campaign_report.md` | Detailed Markdown report |
| `outputs/campaign_summary.json` | Machine-readable delivered-outcome summary |
| `outputs/top100_candidates.csv` | Ranked exploratory candidates and associated flags/properties |
| `outputs/top100_structures.sdf` | Native molecular structure export |
| `outputs/top100_structures.smi` | SMILES identities for the exported structures |
| `outputs/artifact_manifest.csv` | Complete payload list, SHA256 hashes, sizes, sources, lineage and license metadata |

### A.2 Scientific inputs and results

| File or directory in ZIP | Purpose |
|---|---|
| `data/library_qualified.csv` | Reference 1,100-parent eligible discovery library |
| `data/library_qualification_exclusions.csv` | Library qualification exclusions |
| `data/selected_target_potent_assays.json` | Selected-target potency evidence used for exclusions |
| `data/solubility_dataset.csv` | Retained solubility modeling dataset |
| `data/solubility_splits.csv` | Training/calibration/test split assignments |
| `data/solubility_features.npz` | Retained feature arrays |
| `evidence/source_ledger.json` | Source identities and provenance |
| `evidence/family_coverage.csv` | CDK-family assessment coverage |
| `evidence/opportunities.csv` | Evaluated target–indication opportunities |
| `evidence/trial_registry.json` | Retained clinical-registry evidence |
| `structures/panel.json` | Reference docking receptor panel |
| `structures/sources.json` | Structural-source provenance |
| `structures/` | Prepared structural inputs and retained preparation/license records; exact members are in the manifest |
| `docking/` | Native docking poses, batch/job artifacts and logs; exact members are in the manifest |
| `results/assessment_rankings.csv` | Target-opportunity rankings |
| `results/assessment_scores.json` | Decision-model scoring/draw records |
| `results/assessment_robustness.json` | Sensitivity/robustness results |
| `results/assessment_synthesis.json` | Assessment synthesis |
| `results/docking_all_results.csv` | Reconciled docking results; distinguish primary pairs from control/repeated-seed records |
| `results/structure_validation.json` | Receptor/native-pose validation findings |
| `results/matched_protocol_redocking.json` | Matched-protocol redocking results |
| `results/docking_seed_sensitivity.csv` | Repeated-seed sensitivity results |
| `results/qualified_measured_assays.csv` | Retained qualified assay evidence |
| `results/qualified_selectivity_ratios.csv` | Available assay-based selectivity comparisons, subject to comparability limits |
| `results/ranked_all_candidates.csv` | Integrated candidate ranking |
| `results/ranking_summary.json` | Ranking/filter summary |
| `results/top100_activity_evidence.csv` | Activity evidence for the exported candidates |
| `results/solubility_model.joblib` | Fitted model; load only from a trusted, verified archive |
| `results/solubility_metrics.json` | Held-out model-performance metrics |
| `results/solubility_reproducibility.json` | Modeling reproducibility metadata |
| `results/solubility_qualified_predictions.csv` | Predictions and flags for the qualified library |
| `results/solubility_test_predictions.csv` | Held-out test predictions |
| `results/solubility_calibration_predictions.csv` | Calibration-set predictions |
| `raw/` | Retained licensed source records; see manifest for individual members. Included execution logs are stored with their docking/structure artifacts rather than in a separate top-level logs directory |

### A.3 Source scripts included in the ZIP

| Function | Included files under `scripts/` |
|---|---|
| Package verification and presentation | `replay.py`, `render_report.py` |
| Target assessment | `assessment.py` |
| Retrieval, qualification and assay clearance | `harvest.py`, `curate.py`, `kiba.py`, `augment.py`, `chembl_index.py`, `qualified_library.py`, `qualified_evidence.py`, `candidate_assays.py`, `clearance.py`, `final_clearance.py`, `final_metadata.py` |
| Docking and controls | `engine.py`, `dock.py`, `batch.py`, `controls.py`, `matched_controls.py`, `split_counter.py`, `ingest_batches.py`, `seed_analysis.py` |
| Solubility and ranking | `solubility.py`, `rank.py` |

Prepared receptors and provenance are included, but not every original preparation script is in the clean ZIP. The fresh-run agent must resolve those boundaries. The separate operational bundle supplies bounded frozen computation, not a fully automated fresh-run launcher.

### A.4 Operational ZIP contents

The small **`cdk_operational_bundle_v1.zip`** contains the following files, separate from the scientific snapshot. It contains no extracted runs, environments or scientific-data ZIP.

| File in operational ZIP | Purpose |
|---|---|
| `Quick-Start-BioPharma LeadGen.md` | This comprehensive guide, including app launch instruction and fresh-mode prompt |
| `README.txt` | Concise command-line handoff and scope boundaries |
| `workflow.py`, `launch.ps1` | Main launcher and PowerShell wrapper |
| `profile.json` | Snapshot identity, runtime pins, resource limits and acceptance tolerances |
| `acceptance.py` | Semantic comparison of recomputed results and native exports |
| `offline_guard/sitecustomize.py` | Python-level socket connection guard |
| `test_workflow.py` | Standard-library launcher contract tests |
| `test_acceptance.py` | Scientific-dependency comparison tests, including permitted text normalization and rejection of changed numbers/cautions |
| `build_release.py` | Maintainer packaging script; requires a completed reference run and its test evidence; excludes runs/environments and sanitizes host paths |
| `validation/engineering_validation.json` | Sanitized local engineering results and explicit untested boundaries |
| `validation/contract_tests.txt` | Contract-test result |
| `validation/acceptance_tests.txt` | Semantic-comparison test result |
| `validation/reference_receipt.json`, `validation/semantic_acceptance.json` | Sanitized completed reference-run evidence |
| `validation/reference_preflight.json` | Sanitized runtime/dependency readiness record |
| `validation/decision_model.log`, `validation/solubility_inference.log`, `validation/ranking.log`, `validation/semantic_acceptance.log`, `validation/presentation.log` | Sanitized per-stage execution logs |
| `validation/presentation_initial_failure.log` | Preserved initial long-path import failure; the reference receipt records the shorter-path resume rather than claiming an uninterrupted run |
| `bundle_manifest.csv` | SHA256 and byte count for every other file in this small ZIP |

### A.5 Separate release attachments

Publish these assets together in the matching GitHub release. Public availability has not yet been verified.

| Release attachment | Purpose |
|---|---|
| `cdk_operational_bundle_v1.zip` | Launcher, guide and local engineering evidence listed in A.4 |
| `cdk_operational_bundle_v1.sha256` | External checksum for the operational ZIP |
| `cdk_operational_bundle_v1_validation.json` | Operational ZIP integrity/count validation |
| `cdk_operational_bundle_v1_manifest.csv` | External copy of its payload inventory |
| `cdk_non_md_deliverables.zip` | Immutable scientific snapshot listed in A.1–A.3; size/hash pinned in `profile.json` |
| `cdk_non_md_deliverables.sha256` | External checksum for the scientific snapshot |
| `pure_non_md_analysis_timing.md` | Corrected interpretation of recorded pure non-MD analysis time |
| `pure_non_md_analysis_timing.json` | Interval ledger, overlap calculation and timing evidence |

This Quick Start is included in the operational ZIP and should also be published as repository documentation. It is not a member of the immutable scientific snapshot. Any revised archive must receive a new filename/version, checksum and validation record.

**Intentionally absent:** Molecular-dynamics inputs/scripts/results, installed Python environments, Vina binaries, prior archives, secrets, private data and excluded copyrighted full text. Preserving Markdown `.md` reports does not mean molecular dynamics is included.
