"""Standard-library safety/contract tests; no docking, training or installation."""
import io
import json
from contextlib import redirect_stdout
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import workflow


class SafetyTests(unittest.TestCase):
    def test_valid_members(self):
        workflow.members_safe([zipfile.ZipInfo("data/input.csv"), zipfile.ZipInfo("scripts/rank.py")])

    def test_unsafe_members(self):
        for name in ("../escape", "/absolute", "C:/escape", "a\\b", "a/../b", "a/./b", "NUL.txt", "a./b", "a//b"):
            with self.subTest(name=name), self.assertRaises(ValueError):
                workflow.members_safe([zipfile.ZipInfo(name)])

    def test_case_collision(self):
        with self.assertRaises(ValueError):
            workflow.members_safe([zipfile.ZipInfo("A.txt"), zipfile.ZipInfo("a.txt")])

    def test_symlink(self):
        item = zipfile.ZipInfo("link")
        item.external_attr = (stat.S_IFLNK | 0o777) << 16
        with self.assertRaises(ValueError):
            workflow.members_safe([item])

    def test_mutated_snapshot_rejected(self):
        with tempfile.TemporaryDirectory(dir=workflow.BUNDLE) as directory:
            path = Path(directory) / "wrong.zip"
            path.write_bytes(b"not the snapshot")
            with self.assertRaises(ValueError):
                workflow.check_snapshot(path)

    def test_install_requires_consent(self):
        with self.assertRaises(PermissionError):
            workflow.setup(Path("missing.zip"), False)

    def test_run_requires_approval(self):
        with self.assertRaises(PermissionError):
            workflow.run(Path("missing.zip"), "run", "not-created", False)

    def test_network_denied(self):
        p = subprocess.run([sys.executable, "-c", "import socket; socket.create_connection(('127.0.0.1',9))"],
                           env=workflow.environment(), capture_output=True, text=True)
        self.assertNotEqual(p.returncode, 0)
        self.assertIn("Frozen reference computation forbids", p.stderr)

    def test_thread_cap(self):
        env = workflow.environment()
        for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
            self.assertEqual(env[key], "1")
        self.assertEqual(env["CUDA_VISIBLE_DEVICES"], "-1")

    def test_fresh_not_mislabeled_as_reproduction(self):
        p = subprocess.run([sys.executable, str(workflow.BUNDLE / "workflow.py"), "run", "--mode", "fresh"],
                           capture_output=True, text=True)
        self.assertNotEqual(p.returncode, 0)
        self.assertIn("separately agent-led", p.stderr)


class LifecycleTests(unittest.TestCase):
    """Small mocked stages exercise receipts/resume, not scientific correctness."""

    def setUp(self):
        temporary = tempfile.TemporaryDirectory(dir=workflow.BUNDLE)
        self.addCleanup(temporary.cleanup)
        self.bundle = Path(temporary.name)
        for name in ("workflow.py", "acceptance.py", "profile.json"):
            (self.bundle / name).write_text("fixed test source", encoding="utf-8")
        bundle_patch = patch.object(workflow, "BUNDLE", self.bundle)
        bundle_patch.start()
        self.addCleanup(bundle_patch.stop)
        preflight_patch = patch.object(workflow, "preflight", return_value={"errors": []})
        preflight_patch.start()
        self.addCleanup(preflight_patch.stop)
        extract_patch = patch.object(workflow, "extract", side_effect=self.extract_fixture)
        extract_patch.start()
        self.addCleanup(extract_patch.stop)
        payload_patch = patch.object(workflow, "verify_payload", return_value=33442)
        payload_patch.start()
        self.addCleanup(payload_patch.stop)
        self.directory = self.bundle / "runs" / "fixture"

    def extract_fixture(self, snapshot, work):
        work.mkdir()
        for name in workflow.BASELINES:
            path = work / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("unchanged baseline", encoding="utf-8")

    def invoke(self, action="run"):
        with redirect_stdout(io.StringIO()):
            workflow.run(Path("mocked.zip"), action, "fixture", True)

    def receipt(self):
        return json.loads((self.directory / "receipt.json").read_text())

    def test_completed_resume_skips_passed_stages(self):
        with patch.object(workflow, "child") as child:
            self.invoke()
            self.assertEqual(child.call_count, 5)
        with patch.object(workflow, "child") as child:
            self.invoke("resume")
            child.assert_not_called()
        self.assertEqual(self.receipt()["status"], "completed")
        self.assertTrue(all(s["status"] == "passed" for s in self.receipt()["stages"]))

    def test_checkpoint_mutation_blocks_resume(self):
        with patch.object(workflow, "child"):
            self.invoke()
        (self.directory / "work" / "unexpected.txt").write_text("changed")
        with patch.object(workflow, "child") as child, self.assertRaisesRegex(ValueError, "checkpoint"):
            self.invoke("resume")
        child.assert_not_called()
        self.assertEqual(self.receipt()["status"], "failed")

    def test_launcher_change_blocks_resume(self):
        with patch.object(workflow, "child"):
            self.invoke()
        (self.bundle / "workflow.py").write_text("changed source")
        with patch.object(workflow, "child") as child, self.assertRaisesRegex(ValueError, "Launcher/config"):
            self.invoke("resume")
        child.assert_not_called()

    def test_stage_failure_persists_receipt_and_resumes_unchanged_tree(self):
        with patch.object(workflow, "child", side_effect=RuntimeError("test stage failure")):
            with self.assertRaisesRegex(RuntimeError, "test stage failure"):
                self.invoke()
        failed = self.receipt()
        self.assertEqual(failed["status"], "failed")
        self.assertEqual(failed["stages"][0]["status"], "failed")
        self.assertIn("elapsed_wall_seconds", failed["stages"][0])
        with patch.object(workflow, "child") as child:
            self.invoke("resume")
            self.assertEqual(child.call_count, 5)
        self.assertEqual(self.receipt()["status"], "completed")


if __name__ == "__main__":
    unittest.main()
