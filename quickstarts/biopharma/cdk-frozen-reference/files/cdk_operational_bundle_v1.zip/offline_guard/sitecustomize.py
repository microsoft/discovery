"""Deny network access in scientific replay children; source retrieval is not replay."""
import socket


def denied(*args, **kwargs):
    raise PermissionError("Frozen reference computation forbids network access")


socket.socket.connect = denied
socket.socket.connect_ex = denied
socket.create_connection = denied
