"""Package a completed engineering replay without runs, private paths or environments."""
import argparse
import csv
import datetime as dt
import hashlib
import io
import json
import os
from pathlib import Path
import re
import zipfile

import workflow

BUNDLE = workflow.BUNDLE
SOURCE_FILES = (
    "workflow.py", "launch.ps1", "profile.json", "acceptance.py",
    "offline_guard/sitecustomize.py", "test_workflow.py", "test_acceptance.py", "README.txt",
    "Quick-Start-BioPharma LeadGen.md", "build_release.py",
    "validation/contract_tests.txt", "validation/acceptance_tests.txt",
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,60}", args.run_id):
        parser.error("Invalid run ID")
    run = BUNDLE / "runs" / args.run_id
    receipt = json.loads((run / "receipt.json").read_text())
    semantic = json.loads((run / "semantic_acceptance.json").read_text())
    preflight = json.loads((run / "preflight.json").read_text())
    if receipt["status"] != "completed" or semantic["status"] != "passed" or preflight["status"] != "ready":
        raise ValueError("A completed semantic reference replay is required")
    expected_stages = [
        "decision_model", "solubility_inference", "ranking", "semantic_acceptance", "presentation",
    ]
    latest = {stage["name"]: stage for stage in receipt["stages"]}
    if list(latest) != expected_stages or any(s["status"] != "passed" for s in latest.values()):
        raise ValueError("Expected all five reference stages to have successful final attempts")
    for name, expected in receipt["launcher_hashes"].items():
        if workflow.digest(BUNDLE / name) != expected:
            raise ValueError(f"Launcher changed after reference run: {name}")
    contract = (BUNDLE / "validation/contract_tests.txt").read_text(encoding="utf-8-sig")
    if not re.search(r"Ran 14 tests\b", contract) or not re.search(r"^OK\s*$", contract, re.M):
        raise ValueError("Expected successful 14-test contract receipt")
    acceptance_tests = (BUNDLE / "validation/acceptance_tests.txt").read_text(encoding="utf-8-sig")
    if not re.search(r"Ran 7 tests\b", acceptance_tests) or not re.search(r"^OK\s*$", acceptance_tests, re.M):
        raise ValueError("Expected successful 7-test comparison receipt")

    output = args.output_dir.resolve()
    if os.name == "nt" and not str(output).startswith("\\\\?\\"):
        output = Path("\\\\?\\" + str(output))
    if not output.is_dir():
        raise FileNotFoundError("Output directory must already exist")
    stem = "cdk_operational_bundle_v1"
    targets = [output / (stem + suffix) for suffix in (
        ".zip", ".sha256", "_manifest.csv", "_validation.json")]
    if any(p.exists() for p in targets):
        raise FileExistsError("Release outputs exist; choose a new output directory")

    replacements = {
        str(BUNDLE): "<BUNDLE>",
        str(BUNDLE).removeprefix("\\\\?\\"): "<BUNDLE>",
        preflight["executable"]: "<PYTHON_3.13.14>",
        str(Path.home()): "<USER_HOME>",
    }
    replacements.update({
        json.dumps(old)[1:-1]: new for old, new in list(replacements.items())
    })

    def sanitize(value):
        if isinstance(value, dict):
            return {k: sanitize(v) for k, v in value.items()}
        if isinstance(value, list):
            return [sanitize(v) for v in value]
        if isinstance(value, str):
            for old, new in sorted(replacements.items(), key=lambda item: -len(item[0])):
                value = value.replace(old, new)
            return value
        return value

    def encoded(value):
        return (json.dumps(sanitize(value), indent=2, allow_nan=False) + "\n").encode()

    payloads = {name: (BUNDLE / name).read_bytes() for name in SOURCE_FILES}
    payloads["validation/reference_receipt.json"] = encoded(receipt)
    payloads["validation/reference_preflight.json"] = encoded(preflight)
    payloads["validation/semantic_acceptance.json"] = encoded(semantic)
    for stage in expected_stages:
        payloads[f"validation/{stage}.log"] = sanitize(
            (run / (stage + ".log")).read_text(encoding="utf-8")).encode()
    initial_failure = run / "presentation_initial_failure.log"
    if initial_failure.is_file():
        payloads["validation/presentation_initial_failure.log"] = sanitize(
            initial_failure.read_text(encoding="utf-8")).encode()
    engineering = {
        "status": "passed_for_bounded_frozen_reference",
        "generated_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "run_id": args.run_id,
        "contract_tests_passed": 14,
        "semantic_comparison_tests_passed": 7,
        "contract_scope": "Archive/approval/network/thread guards and mocked receipt/failure/resume lifecycle",
        "scientific_acceptance": semantic,
        "analysis_wall_seconds": receipt["analysis_wall_seconds"],
        "scope": "Fixed-input decision scoring, saved-model inference, ranking and retained-report rendering",
        "validation_environment": "Existing Windows host and installed dependencies; no installation performed",
        "recorded_versions": preflight["versions"],
        "reference_source_hashes": receipt["launcher_hashes"],
        "not_tested": [
            "Discovery UI activation", "new-machine dependency installation",
            "fresh end-to-end discovery", "full redocking", "model retraining",
            "public GitHub publication and anonymous download",
        ],
        "resume_scope": "Mocked lifecycle tests plus actual presentation-only resume after shortening the owned run directory; interrupted scientific-job fault injection not tested",
        "known_path_limit": "Use a short extraction folder; Python sibling-module imports can fail at paths longer than Windows MAX_PATH despite extended-path file access",
        "uninterrupted_full_launcher_run": False,
        "sanitization": "Private host paths replaced with placeholders; original receipts retained locally",
        "prior_attempts": [
            {"id": "engineering-reference-01", "outcome": "failed during long-path write preflight"},
            {"id": "engineering-reference-02", "outcome": "interrupted; no completed receipt"},
            {"id": "engineering-reference-03",
             "outcome": "Science stages completed; strict text comparison found only trailing whitespace and a source-added selectivity caution. Numeric/structural comparisons then passed in a diagnostic check. Final launcher rerun from a new extraction."},
            {"id": "engineering-reference-04",
             "outcome": "All scientific and semantic stages passed; presentation sibling import failed at a long Windows path. Run directory shortened to r04, unchanged checkpoint verified, then presentation resumed without repeating analysis."},
        ],
    }
    payloads["validation/engineering_validation.json"] = encoded(engineering)
    for name, content in payloads.items():
        text = content.decode("utf-8-sig")
        if re.search(r"[A-Za-z]:[\\/]+Users[\\/]", text, re.I):
            raise ValueError("Private host path in public payload: " + name)

    inventory = io.StringIO(newline="")
    writer = csv.writer(inventory, lineterminator="\n")
    writer.writerow(["path", "bytes", "sha256"])
    for name, data in sorted(payloads.items()):
        writer.writerow([name, len(data), hashlib.sha256(data).hexdigest()])
    manifest = inventory.getvalue().encode()
    payloads["bundle_manifest.csv"] = manifest
    with zipfile.ZipFile(targets[0], "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in sorted(payloads.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 3, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
    with zipfile.ZipFile(targets[0]) as archive:
        workflow.members_safe(archive.infolist())
        if archive.testzip() is not None or set(archive.namelist()) != set(payloads):
            raise ValueError("Release archive integrity/inventory failed")
        for name, expected in payloads.items():
            if archive.read(name) != expected:
                raise ValueError("Release payload differs: " + name)
    sha = workflow.digest(targets[0])
    targets[1].write_text(f"{sha}  {targets[0].name}\n", encoding="ascii")
    targets[2].write_bytes(manifest)
    targets[3].write_bytes(encoded({
        "status": "passed", "archive": targets[0].name,
        "sha256": sha, "bytes": targets[0].stat().st_size,
        "entries": len(payloads), "manifested_payloads": len(payloads) - 1,
        "checks": ["safe paths", "exact allowlisted inventory", "CRC", "all payload bytes",
                   "manifest hashes", "private host path scan"],
        "scientific_validation": "validation/engineering_validation.json inside archive",
        "snapshot_shipped_separately": workflow.PROFILE["snapshot_name"],
        "snapshot_sha256": workflow.PROFILE["snapshot_sha256"],
        "public_publication": "not performed",
    }))
    print(json.dumps({"archive": str(targets[0]), "sha256": sha, "entries": len(payloads)}))


if __name__ == "__main__":
    main()
