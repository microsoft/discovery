# Discovery hardware design workflow setup

This bundle contains the local catalog, skills, selected agents, and research
documents needed to configure the workflow in another Discovery project.
Copying these files does not by itself register an MCP connection, grant tool
access, create a Bookshelf, or activate an agent in an existing chat.

## Bundle contents

```text
ship/
  discovery_catalog/
  dot-github/
    skills/
    agents/
      hardware-spec-dev.agent.md
      chip-rtl-lint.agent.md
      chip-rtl-design.agent.md
      chip-functional-verification.agent.md
  knowledge/
    bs_data/
  README.md
```

`dot-github` is a transport folder: its contents belong in the destination
project's `.github` folder, not a folder literally named `dot-github`.

The bookshelf data was copied from the source project's `knowledge/bs-data`
into this bundle's `knowledge/bs_data`, including its hidden content.

## Prerequisites

- Docker with a working Linux container engine, or a working Podman runtime.
  On Windows, start Docker Desktop's Linux engine before running the chip agents.
- Network access to the MCP endpoint. Initial container builds also
  need access to the base images, package sources, and tool downloads specified
  by the included Dockerfiles.
- For the report-gen renderer, Python 3.10 or later in the environment where
  it runs. Replace machine-specific Python executable examples with your own
  installation path. The Python inside a suitable existing container can also
  run the renderer with the required project/run folders mounted.

Preserve unrelated destination files. If a target folder or file already exists,
compare and reconcile it before copying; do not blindly overwrite local changes.

## Setup instructions

1. **Place the skills folder in the project `.github` folder.**

   Copy `ship/dot-github/skills` to `<project>/.github/skills`. The resulting
   layout must be `.github/skills/<skill-name>/SKILL.md`, not an extra nested
   `skills/skills` folder. This includes the updated `report-gen` skill and
   renderer with the visual agent invocation sequence.

   Use Discovery's supported skill-loading flow for the trusted destination
   project and verify the skills appear in its runtime catalog. A copied file
   does not establish that a cached skill definition has been refreshed.

2. **Place the agents in the project `.github/agents` folder.**

   Copy all four files from `ship/dot-github/agents` to
   `<project>/.github/agents`. Verify that Discovery discovers these names:
   `hardware-spec-dev`, `chip-rtl-design`, `chip-rtl-lint`, and
   `chip-functional-verification`.

   Use a new or resumed chat after configuring them so current definitions and
   grants are loaded. Catalog discovery alone does not switch an existing chat
   to an agent or prove its updated configuration is active.

3. **Place `discovery_catalog` in the project folder.**

   Copy `ship/discovery_catalog` to `<project>/discovery_catalog`. Keep its
   internal layout intact; the chip agents refer to these relative build
   contexts:

   | Agent | Local image tag | Build context |
   |---|---|---|
   | `chip-rtl-design` | `rtl-design:latest` | `discovery_catalog/chip-rtl-design/tools/rtl-design` |
   | `chip-rtl-lint` | `rtl-lint:latest` | `discovery_catalog/chip-rtl-lint/tools/rtl-lint` |
   | `chip-functional-verification` | `functional-verification:latest` | `discovery_catalog/chip-functional-verification/tools/functional-verification` |

   Run from the destination project root. Confirm the container engine is
   responsive before starting the workflow. The agent definitions inspect
   existing images and build only missing images; the bundle does not include
   prebuilt images or automatically refresh stale image tags. Resolve stale
   images explicitly rather than assuming a copied catalog updates them.

4. **Create a tool called `microchip-catalog` using the current microchip-catalog HTTP MCP endpoint.**

   In Discovery's tool configuration, add an HTTP MCP connection with:

   | Setting | Value |
   |---|---|
   | Connection/tool display name | `microchip-catalog` |
   | Transport | HTTP |
   | Endpoint | `https://api.microchip.com/mcp/resources` |
   | Original source/server name | `microchip-catalog` |

   This is the endpoint from the source project's current microchip-catalog MCP
   configuration. Verify that Discovery connects and exposes the documentation
   tools before assigning them to an agent. The display name `microchip-catalog`
   and original source name `microchip-catalog` refer to this same documentation
   capability; do not assume naming a connection creates a callable tool with
   that exact name.

   If your supported setup uses an imported tool/plugin folder instead of
   entering a connection directly, configure the HTTP server in that folder's
   MCP configuration and import the folder through Discovery. An arbitrary
   project MCP file is not automatically registered.
   No credentials are embedded in this bundle; supply any required
   authentication through the supported connection configuration.

5. **Update `hardware-spec-dev` to have access to the microchip-catalog tool.**

   Grant `hardware-spec-dev` access to `microchip-catalog` connection (the source called `microchip-catalog` in
   the original project). Save the agent configuration.

   The copied agent currently uses the tool-catalog bridge and contains a
   machine-specific `sourceId` in its instructions. If retaining that bridge,
   keep its tool grant and replace the old `sourceId` with the actual source
   identifier registered for the new connection. If using directly exposed MCP
   tools, update the instructions to match those confirmed tool names instead.
   Do not reuse the original machine's identifier or invent a new one.
   Verify access with a small documentation lookup.

6. **Update each of the three chip agents to have all `discovery.bookshelf.*` tool access.**

   For `chip-rtl-design`, `chip-rtl-lint`, and
   `chip-functional-verification`, grant every available Bookshelf operation
   whose name begins with `discovery.bookshelf`, including listing shelves,
   searching, and asking grounded questions. Tool names can be displayed with
   runtime-specific prefixes; select all exposed Bookshelf operations in the
   agent's supported tool-access configuration.

   Save the grants and verify that each agent can list the available
   Bookshelves. Tool-access instructions written in a Markdown file do not
   themselves grant access.

7. **Create a Bookshelf called `Design-Best-Practices` using `knowledge/bs_data`.**

   Copy `ship/knowledge/bs_data` to `<project>/knowledge/bs_data`.
   In Discovery:

   - Go to **AI Capabilities** and select **Bookshelves**.
   - Select **New Bookshelf**.
   - Enter the name `Design-Best-Practices`
   - Use the following for the description:
   "The bookshelf contains chip design best practices and guidance on Verilog/SystemVerilog RTL coding, synthesis pitfalls, lint/static analysis, simulation semantics, assertions, UVM testbenches, coverage, CDC/reset handling, and debugging. It is most useful for writing synthesizable RTL, preventing simulation–synthesis mismatches, building self-checking verification environments, improving stimulus and coverage models, and diagnosing regression failures. Its emphasis is front-end digital chip design and verification, rather than physical implementation, timing closure, power analysis, or tapeout signoff."
   - Select the destination project's `knowledge/bs_data` folder as the source.
   - Create the Bookshelf.

   Wait for ingestion and indexing to finish, then verify it appears when
   listing shelves and that a search returns supporting passages. Review the
   imported selection so auxiliary metadata is not mistaken for research
   papers.

   Attach this Bookshelf to the three chip agents through the available
   grounding configuration. Their instructions prioritize attached shelves over
   fallback shelf names.

8. **Run the test prompt below.**
Use this test
   prompt verbatim; the original spelling is preserved:

```text
First, use hardware-spec-dev agent to create the CoreSPI specification document (select 'Recommended' if prompted by chat).
Next, create a specification markdown document in knowledge directory for the CORESPI_HB device.
Then use these three agents in order to implement and verify the design described in knowledge/CORESPI_HB.md:

chip-rtl-design: Read the specification, create synthesizable veirlog, and run the design checks.
chip-rtl-lint: Check the RTL with the default lint rules and canonical formatting check. Fix any issues before continuing.
chip-functional-verification: Create an independent, self-checking testbench from the specification, run simulation, and produce a VCD waveform.
If the RTL changes, repeat all checks on the final version. Report PASS only when design checks, lint, formatting, and simulation all pass. Otherwise, report the actual failure.

Save the RTL, testbench, waveform, and a short results summary, and provide links to them. Save all generated files—including RTL, testbench, logs, waveform, and results summaries—under results/<unique-run-id>/ in this project, rather than under sessions/.
```

A passing result would be indicated by the following:
- a final HTML report generated using the report-gen skill.
- Each of these agents were executed at least once:
hardware-spec-dev
chip-rtl-design
chip-rtl-lint
chip-functional-verification
- hardware-spec-dev connection to MCP server was successful
- The chip-* agents all referenced the bookshelf
- Verilog design file(s) created
- Verilog testbench file(s) created
- Docker tools executed when chip-rtl-lint and chip-functional-verification agents executed

