# chip-functional-verification — Functional Verification Agent

Node-agnostic **functional-verification** agent. Compiles RTL + a testbench with
**Icarus Verilog** (`iverilog`), runs the compiled object with `vvp`, and reports
a fail-closed verdict with a required nonempty VCD for Icarus self-check success.

- **Engine:** Icarus Verilog (`iverilog -g<std> -o sim.vvp ...` + `vvp sim.vvp`)
- **Node awareness:** node-agnostic (no PDK binding).
- **Output:** Common Design Envelope (`/output/common_design_envelope.json`); any dumped
  VCD is preserved under `results/`.

## Scenario

| Scenario | Purpose |
|---|---|
| `run_sim` | Compile RTL + testbench, run the event simulation, report pass/fail + VCD. |

## Ordinary local execution

This OpenSTA-style package includes `agent.yaml`, `metadata.yaml`, README and the
complete `tools/functional-verification` build context. It has no shared-code or
host-launcher dependency. Discovery parent owns dispatch and handoffs.

Use `.github/skills/discovery-add-agents/SKILL.md` Steps 5/6 with local
`$srcRoot=agents-docker` and exactly the three selected roles, not an upstream
refresh that would discard these edits. Copy only to an absent destination:

```powershell
$name = 'chip-functional-verification'
$dst = Join-Path (Get-Location) "discovery_catalog\$name"
if (Test-Path $dst) { throw "Destination exists: $dst" }
New-Item -ItemType Directory -Force discovery_catalog | Out-Null
Copy-Item -Recurse "agents-docker\$name" $dst
# Run the skill's Step 6 with $selected=@($name).
```

Local copy/companion generation supplies lazy bootstrap, **not action registration
or mounts**. YAML IDs do not become callable Copilot tools. Use `run` only if
actually registered with the mounts below; otherwise invoke one container directly.
The fixed action reads `/input/params.json` using the contract in
`tools/functional-verification/params.schema.json`, never shell-interpolated JSON.

Importer image: **`functional-verification:latest`**. Inspect first; only if absent:
`docker build -t functional-verification:latest agents-docker\chip-functional-verification\tools\functional-verification`.
After import use `discovery_catalog\chip-functional-verification\tools\functional-verification`.
Podman uses the same arguments. Engine installation, readiness and context are
integration responsibilities. Existing tags are not automatically refreshed by
source edits; explicitly select a source-current image.

PowerShell single-operation example, from project root:

```powershell
$op = Join-Path (Get-Location) ("results\functional-verification-" + [guid]::NewGuid().ToString('N'))
if (Test-Path $op) { throw "Operation already exists: $op" }
New-Item -ItemType Directory $op -ErrorAction Stop | Out-Null
'input','output','work','tmp','var-tmp','home','run','shm','evidence' | ForEach-Object {
    New-Item -ItemType Directory (Join-Path $op $_) -ErrorAction Stop | Out-Null
}
# Copy only frozen dut.v and independent tb_dut.v (module tb) into "$op\input".
'{"scenario":"run_sim","top":"tb","rtl_files":["/input/dut.v"],"testbench_files":["/input/tb_dut.v"],"generation":"2012","wave_format":"vcd"}' |
    Set-Content "$op\input\params.json" -Encoding utf8
docker run --rm --pull=never --read-only --network=none --cpus=2 --memory=4g --pids-limit=256 `
    --mount "type=bind,source=$op\input,target=/input,readonly" `
    --mount "type=bind,source=$op\output,target=/output" `
    --mount "type=bind,source=$op\work,target=/workdir" `
    --mount "type=bind,source=$op\tmp,target=/tmp" `
    --mount "type=bind,source=$op\var-tmp,target=/var/tmp" `
    --mount "type=bind,source=$op\home,target=/home/worker" `
    --mount "type=bind,source=$op\run,target=/run" `
    --mount "type=bind,source=$op\shm,target=/dev/shm" `
    functional-verification:latest python3 -B -u /app/run.py --params-file /input/params.json `
    1> "$op\evidence\stdout.log" 2> "$op\evidence\stderr.log"
$containerExit = $LASTEXITCODE
$containerExit | Set-Content "$op\evidence\container-exit.txt"
Get-Content "$op\output\common_design_envelope.json" -Raw
```

All mount sources and evidence are real, absolute host-native paths beneath results.
Reject links/junctions, do not use tmpfs, and never write runtime data to the source
tree. Dockerfile sets HOME, TMPDIR/TMP/TEMP and XDG_CACHE_HOME to the persistent
mounts. For POSIX adapt host separators/quoting. Windows integration may add
`--context desktop-linux` before `run`/`build`. Unavailable engine/image/action/mounts
is BLOCKED; never install software or invent a tool call.

Return actual container exit, native compile/sim codes, CDE status/verdict/error and
waveform separately. CDE references resolve under `$op\output`. Worker refuses
nonempty output/work; retain failures and use fresh operation paths for retries.
Preserve RTL/TB hashes and do not modify DUT. Run packaged regressions in this
mount layout using `python3 -B -m unittest discover -s /app -p 'test_*.py' -v`.
GHDL/cocotb/GLS paths are retained but are not substitutes for the Icarus contract.

## Verdict discipline

Icarus success requires exactly one `COMPARISONS=n MISMATCHES=m` summary with
n > 0 and m = 0, an exact standalone `TEST PASSED`, no error/failure/fatal markers,
native compile/sim exits 0 and a nonempty VCD. Generic success prose, missing or
incorrect markers, zero comparisons and missing waveform all fail closed. A pass
marker never overrides an error. Read these measured fields in the CDE; absent
metrics do not pass. This does not establish timing or CDC signoff.
