# chip-rtl-lint — RTL Lint and Style Agent

Node-agnostic **RTL lint / style** agent driven by **Verible**.

- **Engine:** Verible (`verible-verilog-lint`, `verible-verilog-format`)
- **Node awareness:** node-agnostic — lint does not consume a PDK binding.
- **Output:** Common Design Envelope (`/output/common_design_envelope.json`).

## Scenarios

| Scenario | Purpose |
|---|---|
| `lint` | `verible-verilog-lint` over sources with optional `rules`/`ruleset`/`waiver_files`; reports violation count + per-rule breakdown. Zero => pass. |
| `format` | `verible-verilog-format --verify` per source; reports how many are not canonically formatted. |
| `lint_gate` | Combined DEFAULT lint and canonical formatting gate; both required for stage closure. |

## Ordinary local execution

This OpenSTA-style package contains `agent.yaml`, `metadata.yaml`, README and the
complete `tools/rtl-lint` Dockerfile context. No shared code or host launcher is
required. Discovery parent owns specialist activation and handoffs.

Use local `.github/skills/discovery-add-agents/SKILL.md` Steps 5/6 with
`$srcRoot` set to `agents-docker` and exactly the three selected role folders.
Do not refresh these local edits from upstream. Copy only to an absent destination:

```powershell
$name = 'chip-rtl-lint'
$dst = Join-Path (Get-Location) "discovery_catalog\$name"
if (Test-Path $dst) { throw "Destination exists: $dst" }
New-Item -ItemType Directory -Force discovery_catalog | Out-Null
Copy-Item -Recurse "agents-docker\$name" $dst
# Run the skill's Step 6 with $selected=@($name).
```

The Local branch only copies and generates companions/lazy image bootstrap:
**no YAML action registration or mount configuration occurs**. IDs are not callable
Copilot tools. Invoke `run` only if genuinely registered and these mounts are
available. Otherwise directly invoke one container, without a host runner.
The fixed action reads `/input/params.json`, described by
`tools/rtl-lint/params.schema.json`; it does not interpolate JSON into shell text.

Importer image: **`rtl-lint:latest`**. Inspect first; only if missing:
`docker build -t rtl-lint:latest agents-docker\chip-rtl-lint\tools\rtl-lint`.
After import the context is `discovery_catalog\chip-rtl-lint\tools\rtl-lint`.
Podman takes the same arguments. Installation, daemon readiness and context
selection belong to integration. Existing images are not refreshed after edits:
select a source-current tag explicitly, never silently use stale source.

PowerShell single-operation example, from project root:

```powershell
$op = Join-Path (Get-Location) ("results\rtl-lint-" + [guid]::NewGuid().ToString('N'))
if (Test-Path $op) { throw "Operation already exists: $op" }
New-Item -ItemType Directory $op -ErrorAction Stop | Out-Null
'input','output','work','tmp','var-tmp','home','run','shm','evidence' | ForEach-Object {
    New-Item -ItemType Directory (Join-Path $op $_) -ErrorAction Stop | Out-Null
}
# Copy only frozen final RTL to "$op\input"; this example expects dut.v.
'{"scenario":"lint_gate","sources":["/input/dut.v"],"ruleset":"default","format_gating":true,"indentation_spaces":2}' |
    Set-Content "$op\input\params.json" -Encoding utf8
docker run --rm --pull=never --read-only --network=none --cpus=2 --memory=4g --pids-limit=256 `
    --mount "type=bind,source=$op\input,target=/input,readonly" `
    --mount "type=bind,source=$op\output,target=/output" `
    --mount "type=bind,source=$op\work,target=/workdir" `
    --mount "type=bind,source=$op\tmp,target=/tmp" `
    --mount "type=bind,source=$op\var-tmp,target=/var/tmp" `
    --mount "type=bind,source=$op\home,target=/home/worker" `
    --mount "type=bind,source=$op\run,target=/run" `
    --mount "type=bind,source=$op\shm,target=/dev/shm" `
    rtl-lint:latest python3 -B -u /app/run.py --params-file /input/params.json `
    1> "$op\evidence\stdout.log" 2> "$op\evidence\stderr.log"
$containerExit = $LASTEXITCODE
$containerExit | Set-Content "$op\evidence\container-exit.txt"
Get-Content "$op\output\common_design_envelope.json" -Raw
```

All mount sources and evidence must be real absolute native paths beneath results,
not linked files/junctions. No tmpfs or source-tree writes. Dockerfile sets HOME,
TMPDIR/TMP/TEMP and XDG_CACHE_HOME to these persistent mounts. For POSIX use native
separators/quoting. Windows integration may add `--context desktop-linux` before
`run`/`build`. Missing image, engine, action or mounts is BLOCKED, not permission
to install software or invent a tool call.

Require actual exit 0, CDE completed/pass, DEFAULT violations 0 and unformatted
files 0. No waivers, rules/config overrides, style not_gating or disabled format
gating for closure. Optional diagnostic configurations remain available but are
not DEFAULT closure. Standalone `lint` and `format` cannot close the stage.
Return container exit, native subcheck codes, CDE status/verdict/error and proposals
separately. CDE references resolve under `$op\output`. Keep proposals separate;
never mutate inputs. Worker refuses nonempty output/work. Each retry gets a fresh
operation. Preserve hashes; adopted RTL changes require all three parent-routed gates.
Run packaged regressions in the same mount layout with
`python3 -B -m unittest discover -s /app/tests -p 'test_*.py' -v`.

## Review discipline

Lint is a review gate: zero violations passes, any violation fails. Waivers are
applied only via the caller-supplied `waiver_files`; rules are never silently
ignored. Verible is installed from the upstream static linux release (no Debian
package exists).

## Historical build maintenance

The Verible version is pinned in the Containerfile (`ARG VERIBLE_VER`) for
reproducible builds. Version upgrades are outside this backend-only migration.
Use the supervised staged Docker plan without overriding the pinned version:

```powershell
python agents-docker\shared\build_docker.py --check --run-id <run-id>
```

Latest tags: <https://github.com/chipsalliance/verible/releases>.
