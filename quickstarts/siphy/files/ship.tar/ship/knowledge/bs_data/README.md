# Local RTL design and verification reading collection

**40 local PDFs: 10 originals + 30 additions; 667 physical pages. Hard cap: 50, including originals.**

A practitioner-oriented collection of substantial technical/conference papers, with the original research preprints and presentation retained. No dissertations, new slide decks, textbook copies, Bookshelf ingestion or engineering deliverables were added. Stopping is based on complementary coverage/source quality, not a quota.

## Coverage

Counts are **nonexclusive**: a document can contribute to several topics. Tags indicate subject matter, not independently established effectiveness. FIFO includes a channel-modeling paper (16) and an actual asynchronous RTL implementation (21b).

| Tag | Subject | PDFs |
| --- | --- | ---: |
| RTL | RTL coding | 14 |
| LINT | Deterministic lint/static analysis | 15 |
| TB | Functional simulation/testbench design | 19 |
| SVA | Assertions | 6 |
| COV | Coverage/constrained-random verification | 11 |
| CDC | CDC | 3 |
| RST | Reset/RDC | 5 |
| FIFO | FIFO design/modeling | 2 |
| DBG | Verification-failure debugging | 20 |
| RESEARCH | Static-analysis research (not deterministic-lint guidance) | 2 |

Practical routes: RTL/lint 01, 03, 15, 18-20, 27, 37; deterministic verification lint 26, 28, 41; simulation/X/DPI/UVM 02, 12, 13, 16, 17, 25, 32, 44; assertions 11, 14, 26, 38; coverage/randomization 30-33, 40-42; CDC/FIFO 21b, 38, 39; reset/RDC 09, 34-36; failure localization/triage 07, 08, 43, plus the topic-specific debugging papers.

## Full local index

P = practitioner technical/conference paper; R = research paper; PP = preprint; S = presentation. Every title links to the actual local PDF. Source URLs below identify the acquired copy; original/resolved URLs, timestamps, bytes, SHA-256, native page counts, host basis, rights and evidence paths are in [manifest.json](manifest.json).

| ID | Actual title / local PDF | Authors; year | Kind; pages | Topics | Source |
| --- | --- | --- | --- | --- | --- |
| 01 | [Nonblocking Assignments in Verilog Synthesis, Coding Styles That Kill!](01-cummings-nonblocking-assignments-2000.pdf) | Clifford E. Cummings; 2000 | P; 23 | RTL, LINT, TB | [source](https://csg.csail.mit.edu/6.375/6_375_2007_www/papers/cummings-nonblocking-snug99.pdf) |
| 02 | [SystemVerilog Event Regions, Race Avoidance & Guidelines](02-cummings-systemverilog-event-regions-2006.pdf) | Clifford E. Cummings, Arturo Salz; 2006 | P; 42 | TB, DBG | [source](https://rfsoc.mit.edu/6S965/_static/F25/lectures/CummingsSNUG2006Boston_SystemVerilog_Events.pdf) |
| 03 | [Gotcha Again: More Subtleties in the Verilog and SystemVerilog Standards That Every Engineer Should Know](03-sutherland-mills-gotcha-again-2007.pdf) | Stuart Sutherland, Don Mills, Chris Spear; 2007 | P; 44 | RTL, LINT, TB, DBG | [source](https://sutherland-hdl.com/papers/2007-SNUG-SanJose_gotcha_again_paper.pdf) |
| 04 | [What, If Anything, In SystemVerilog Will Help Me With FPGA-based Designs?](04-sutherland-systemverilog-fpga-design-2012.pdf) | Stuart Sutherland; unresolved | P; 18 | RTL | [source](https://sutherland-hdl.com/papers/2012-DesignCon_SV-for-FPGAs_paper.pdf) |
| 05 | [Qihe: A General-Purpose Static Analysis Framework for Verilog](05-qihe-verilog-static-analysis-2026.pdf) | Qinlin Chen, Nairen Zhang, Jinpeng Wang, Jiacai Cui, Tian Tan, Xiaoxing Ma, Chang Xu, Jian Lu, Yue Li; 2026 | PP; 34 | RESEARCH | [source](https://arxiv.org/pdf/2601.11408) |
| 06 | [LintLLM: An Open-Source Verilog Linting Framework Based on Large Language Models](06-lintllm-verilog-linting-2025.pdf) | Zhigang Fang, Renzhi Chen, Zhijie Yang, Yang Guo, Huadong Dai, Lei Wang; 2025 | PP; 7 | RESEARCH | [source](https://arxiv.org/pdf/2502.10815) |
| 07 | [Improved Design Debugging using Maximum Satisfiability](07-improved-design-debugging-maxsat-2007.pdf) | Sean Safarpour, Hratch Mangassarian, Andreas Veneris, Mark H. Liffiton, Karem A. Sakallah; 2007 | R; 7 | DBG | [source](https://markliffiton.com/publications/fmcad07_safarpour_debugging.pdf) |
| 08 | [Debugging RTL using Structural Dominance](08-debugging-rtl-structural-dominance-2013.pdf) | Hratch Mangassarian, Bao Le, Andreas Veneris; 2013 | R; 14 | DBG | [source](https://www.eecg.utoronto.ca/~veneris/13tcad2.pdf) |
| 09 | [Asynchronous & Synchronous Reset Design Techniques - Part Deux](09-reset-design-techniques-part-deux-2003.pdf) | Clifford E. Cummings, Don Mills, Steve Golson; 2003 | P; 38 | RTL, LINT, RST | [source](https://www.trilobyte.com/pdf/CummingsSNUG2003Boston_Resets_rev1_2.pdf) |
| 10 | [Synthesizing SystemVerilog: Busting the Myth that SystemVerilog is only for Verification](10-synthesizing-systemverilog-2013-slides.pdf) | Stuart Sutherland, Don Mills; 2013 | S; 31 | RTL | [source](https://sutherland-hdl.com/papers/2013-SNUG-SV_Synthesizable-SystemVerilog_presentation.pdf) |
| 11 | [Who Put Assertions In My RTL Code? And Why? How RTL Design Engineers Can Benefit from the Use of SystemVerilog Assertions](11-sva-for-rtl-designers-2015.pdf) | Stuart Sutherland; 2015 | P; 26 | RTL, SVA, DBG | [source](https://sutherland-hdl.com/papers/2015-SNUG-SV_SVA-for-RTL-Designers_paper.pdf) |
| 12 | [UVM Rapid Adoption: A Practical Subset of UVM](12-uvm-rapid-adoption-2015.pdf) | Stuart Sutherland, Tom Fitzpatrick; 2015 | P; 28 | TB, COV | [source](https://sutherland-hdl.com/papers/2015-DVCon_UVM-rapid-adoption_paper.pdf) |
| 13 | [I'm Still In Love With My X! (but, do I want my X to be an optimist, a pessimist, or eliminated?)](13-in-love-with-my-x-2013.pdf) | Stuart Sutherland; 2013 | P; 20 | RTL, TB, DBG | [source](https://sutherland-hdl.com/papers/2013-DVCon_In-love-with-my-X_paper.pdf) |
| 14 | [Adding Last-Minute Assertions to a Design and Verification Project: Lessons Learned (a little late) about Designing for Verification](14-adding-assertions-2009.pdf) | Stuart Sutherland; unresolved | P; 7 | SVA, COV, TB, DBG | [source](https://sutherland-hdl.com/papers/2009-DVCon_Adding_Assertions_paper.pdf) |
| 15 | [SystemVerilog Saves the Day—the Evil Twins are Defeated! "unique" and "priority" are the new Heroes](15-systemverilog-unique-priority-2005.pdf) | Stuart Sutherland; 2005 | P; 24 | RTL, LINT, TB | [source](https://sutherland-hdl.com/papers/2005-SNUG-paper_SystemVerilog_unique_and_priority.pdf) |
| 16 | [Modeling FIFO Communication Channels Using SystemVerilog Interfaces](16-systemverilog-fifo-channel-2004.pdf) | Stuart Sutherland; 2004 | P; 24 | FIFO, TB | [source](https://sutherland-hdl.com/papers/2004-SNUG-Boston-paper_SystemVerilog_FIFO_Channel.pdf) |
| 17 | [The Verilog PLI Is Dead (maybe) ... Long Live The SystemVerilog DPI!](17-verilog-pli-versus-dpi-2004.pdf) | Stuart Sutherland; 2004 | P; 18 | TB, DBG | [source](https://sutherland-hdl.com/papers/2004-SNUG-paper_Verilog_PLI_versus_SystemVerilog_DPI.pdf) |
| 18 | ["full_case parallel_case", the Evil Twins of Verilog Synthesis](18-cummings-case-directives-1999.pdf) | Clifford E. Cummings; 1999 | P; 20 | RTL, LINT, DBG | [source](https://csg.csail.mit.edu/6.375/6_375_2007_www/papers/cummings-case-snug99.pdf) |
| 19 | [RTL Coding Styles That Yield Simulation and Synthesis Mismatches](19-cummings-synthesis-mismatches-1999.pdf) | Don Mills, Clifford E. Cummings; 1999 | P; 16 | RTL, LINT, TB, DBG | [source](https://csg.csail.mit.edu/6.375/6_375_2007_www/papers/cummings-synth-mismatch-snug99.pdf) |
| 20 | [New Verilog-2001 Techniques for Creating Parameterized Models (or Down With `define and Death of a defparam!)](20-cummings-parameterized-design-2002.pdf) | Clifford E. Cummings; 2002 | P; 10 | RTL, LINT | [source](https://csg.csail.mit.edu/6.375/6_375_2007_www/papers/cummings-paramdesign-hdlcon02.pdf) |
| 21b | [Simulation and Synthesis Techniques for Asynchronous FIFO Design](21b-cummings-asynchronous-fifo-2002.pdf) | Clifford E. Cummings; 2002 | P; 23 | RTL, CDC, FIFO, RST | [source](https://userpages.cs.umbc.edu/tinoosh/cmpe316/tutorials/FIFO.pdf) |
| 25 | [Keeping Score: Part 1 of 2 - Architectural Considerations for Scoreboard Design](25-scoreboard-architecture-2012.pdf) | Gordon Allan; 2012 | P; 11 | TB, COV, DBG | [source](https://dvcon-proceedings.org/wp-content/uploads/keeping-score-part-1-of-2-architectural-considerations-for-scoreboard-design.pdf) |
| 26 | [SystemVerilog Assertion Linting: Closing Potentially Critical Verification Holes](26-assertion-linting-2012.pdf) | Laurence S. Bisht, Dmitry Korchemny, Erik Seligman; 2012 | P; 8 | LINT, SVA, DBG | [source](https://dvcon-proceedings.org/wp-content/uploads/systemverilog-assertion-linting-closing-potentially-critical-verification-holes.pdf) |
| 27 | [Arithmetic Overflow Verification using Formal LINT](27-formal-lint-arithmetic-overflow-2024.pdf) | Kaiwen Chin, Esra Sahin Basaran, Kranthi Pamarthi; 2024 | P; 11 | RTL, LINT | [source](https://dvcon-proceedings.org/wp-content/uploads/1020-1.pdf) |
| 28 | [Testbench Linting - open-source way: Using slang/pyslang/PySlint](28-testbench-linting-open-source-2023.pdf) | Srinivasan Venkataramanan, Deepa Palaniappan, Satinder Paul Singh; 2023 | P; 9 | LINT, TB, SVA, COV | [source](https://dvcon-proceedings.org/wp-content/uploads/92146.pdf) |
| 30 | [Systematic Constraint Relaxation (SCR): Hunting for Over-Constrained Stimulus](30-systematic-constraint-relaxation-2022.pdf) | Debarshi Chatterjee, Spandan Kachhadiya, Ismet Bayraktaroglu, Siddhanth Dhodhi; 2022 | P; 5 | COV, DBG | [source](https://dvcon-proceedings.org/wp-content/uploads/Systematic-Constraint-Relaxation-SCR-Hunting-for-Over-Constrained-Stimulus-1.pdf) |
| 31 | [Coverage Driven Distribution of Constrained Random Stimuli](31-coverage-driven-stimulus-distribution-2015.pdf) | Marat Teplitsky, Amit Metodi, Raz Azaria; 2015 | P; 8 | COV | [source](https://dvcon-proceedings.org/wp-content/uploads/coverage-driven-distribution-of-constrained-random-stimuli.pdf) |
| 32 | [The Top Most Common SystemVerilog Constrained Random Gotchas](32-constrained-random-gotchas-2014.pdf) | Ahmed Yehia; 2014 | P; 10 | COV, TB, DBG | [source](https://dvcon-proceedings.org/wp-content/uploads/the-top-most-common-systemverilog-constrained-random-gotchas.pdf) |
| 33 | [Error Injection in a Subsystem Level Constrained Random UVM Testbench](33-error-injection-uvm-testbench-2018.pdf) | J. Ridgeway, H. Nguyen; 2018 | P; 14 | TB, COV, DBG | [source](https://dvcon-proceedings.org/wp-content/uploads/error-injection-in-a-subsystem-level-constrained-random-uvm-testbench.pdf) |
| 34 | [Building And Modelling Reset Aware Testbench For IP Functional Verification](34-reset-aware-testbench-2019.pdf) | Naishal Shah; 2019 | P; 7 | RST, TB, DBG | [source](https://dvcon-proceedings.org/wp-content/uploads/building-and-modelling-reset-aware-testbench-for-ip-functional-verification.pdf) |
| 35 | [Comprehensive and Automated Static Tool Based Strategies for the Detection and Resolution of Reset Domain Crossings](35-static-reset-domain-crossing-2017.pdf) | Yossi Mirsky; 2017 | P; 13 | RST, LINT | [source](https://dvcon-proceedings.org/wp-content/uploads/comprehensive-and-automated-static-tool-based-strategies-for-the-detection-and-resolution-of-reset-domain-crossings.pdf) |
| 36 | [On analysis of RDC issues for identifying reset tree design bugs and further strategies for noise reduction](36-reset-tree-bugs-noise-reduction-2024.pdf) | Farhad Ahmed, Lyle Benson, Manish Bhati; 2024 | P; 6 | RST, LINT | [source](https://dvcon-proceedings.org/wp-content/uploads/1088-1.pdf) |
| 37 | [State Machine Coding Styles for Synthesis](37-cummings-fsm-coding-1998.pdf) | Clifford E. Cummings; 1998 | P; 20 | RTL, LINT | [source](https://userpages.cs.umbc.edu/ameyk1/CummingsSNUG1998SJ_FSM.pdf) |
| 38 | [SystemVerilog Assertions for Clock-Domain-Crossing Data Paths](38-sva-cdc-data-paths-2015.pdf) | Don Mills; 2015 | P; 23 | CDC, SVA, TB, DBG | [source](https://dvcon-proceedings.org/wp-content/uploads/systemverilog-assertions-for-clock-domain-crossing-data-paths.pdf) |
| 39 | [Pragmatic Formal Verification Methodology for Clock Domain Crossing (CDC)](39-pragmatic-formal-cdc-2023.pdf) | Aman Kumar, Muhammad Ul Haque Khan, Bijitendra Mittra; 2023 | P; 11 | CDC, LINT, SVA, TB | [source](https://dvcon-proceedings.org/wp-content/uploads/91837.pdf) |
| 40 | [Navigating The Functional Coverage Black Hole: Be More Effective At Functional Coverage Modeling](40-functional-coverage-modeling-2015.pdf) | Jason Sprott, Paul Marriott, Matt Graham; 2015 | P; 12 | COV, TB | [source](https://dvcon-proceedings.org/wp-content/uploads/navigating-the-functional-coverage-black-hole-be-more-effective-at-functional-coverage-modeling.pdf) |
| 41 | [Static Checking for Correctness of Functional Coverage Models](41-static-functional-coverage-checking-2017.pdf) | Wael Mahmoud; 2017 | P; 8 | COV, LINT | [source](https://dvcon-proceedings.org/wp-content/uploads/static-checking-for-correctness-of-functional-coverage-models-paper.pdf) |
| 42 | [Debugging Functional Coverage Models: Get The Most Out of Your Cover Crosses](42-debugging-cover-crosses-2018.pdf) | Mennatallah Amer, Amr Hany; 2018 | P; 8 | COV, DBG | [source](https://dvcon-proceedings.org/wp-content/uploads/debugging-functional-coverage-models-get-the-most-out-of-your-cover-crosses.pdf) |
| 43 | [Failure Triage: The Neglected Debugging Problem](43-failure-triage-2012.pdf) | Sean Safarpour, Evean Qin, Yu-Shen Yang; 2012 | P; 6 | DBG | [source](https://dvcon-proceedings.org/wp-content/uploads/failure-triage-the-neglected-debugging-problem.pdf) |
| 44 | [So There's My Bug! Debugging Universal Verification Methodology (UVM) Environments](44-debugging-uvm-environments-2011.pdf) | Mike Floyd; 2011 | P; 3 | TB, DBG | [source](https://dvcon-proceedings.org/wp-content/uploads/so-theres-my-bug-debugging-universal-verification-methodology-uvm-environments.pdf) |

## Distinct practical contribution of each addition

- **11** — Embedded versus bound assertions, immediate/concurrent assertion choices, one-hot checks and assertion controls. Direct RTL-designer guidance rather than a verification-only introduction.
- **12** — A worked, deliberately small UVM environment: transactions, drivers, monitors, checking, configuration and a compact API subset.
- **13** — X optimism/pessimism, two-state versus four-state simulation, initialization and coding alternatives for elusive simulation/silicon mismatches.
- **14** — A concrete late-project coverage/assertion case study: passing randomized tests, missing checks, protocol observability and specification/testbench obstacles.
- **15** — Detailed unique/priority decision semantics, simulation checks, synthesis assumptions and comparison with full_case/parallel_case directives.
- **16** — Interfaces, modports, parameterized communication channels, queues and mailboxes; useful for testbench abstraction and model boundaries.
- **17** — C/reference-model integration, pure/context DPI calls, data types and retained PLI capabilities; identifies causes of unpredictable simulation results and crashes.
- **18** — Concrete directive-induced synthesis/simulation mismatches, unintended don't-cares and case overlap; foundational rationale for deterministic lint rules.
- **19** — Sensitivity lists, assignment/case pitfalls and corrected coding examples; explains the engineering reasons behind many RTL lint checks.
- **20** — Reusable parameterized RTL, parameter overrides, local constants, global macro leakage and defparam hazards.
- **21b** — Full FIFO style #1 RTL, synchronized Gray pointers, full/empty generation, partitioning and synthesis/analysis considerations.
- **25** — Self-checking architecture, expected/observed data, ordering, aggregation, extent and succession in complex scoreboards.
- **26** — Experience-derived deterministic checks for wrong assertion functionality, ignored/vacuous checks and simulation/formal performance hazards.
- **27** — Structural versus formal lint, signedness, expression sizing, sign extension and concrete RTL coding guidelines for overflow detection.
- **28** — AST-based deterministic testbench checks, custom Python rules, policy control, portability and CI/CD integration, with concrete rule examples.
- **30** — Detects silent over-constraint from stale workarounds and specification drift; distinguishes legal expansion from unsupported stimulus and checker failures.
- **31** — Distribution directives and their limitations, coverage-aware stimulus distribution, and worked SystemVerilog/e examples.
- **32** — Constraint-solving pitfalls, object/thread RNGs, random stability, construction order and reproducibility across testbench edits.
- **33** — Error-injection services, expected error demotion, recovery, scoreboards and interrupt-service sequences without reducing all error tests to directed cases.
- **34** — Reset-aware drivers, monitors, sequencers and recovery; outstanding requests, sequence termination and queue flushing.
- **35** — RDC risk even within one clock domain, reset-domain definitions and ordering, static detection and practical resolution strategies.
- **36** — Non-resettable registers in reset trees, stable/constant constraints, functional false paths and avoiding unsafe noise suppression.
- **37** — FSM structure, Moore/Mealy distinctions, encoding choices and one-/two-always coding styles, with synthesis-oriented examples.
- **38** — Multi-clock assertion sampling versus event-driven data activity, frequency-sensitive false failures and worked corrected CDC properties.
- **39** — Combines structural CDC checking, functional assertions and metastability injection, including reuse of IP-level setup in SoC simulation.
- **40** — Coverage planning, requirement/check traceability, abstraction, cross coverage, reviews and model correctness; an engineering counterweight to raw coverage percentages.
- **41** — Static/formal and constraint-based analysis of unreachable bins and mismatches among coverage specifications, testbench constraints and RTL.
- **42** — Multi-cross hole analysis, bin density and hole-effect metrics to prioritize coverage-model/constraint investigation.
- **43** — Regression failure signatures, suspect-based clustering, ownership assignment and limits of binning failures solely by checker messages.
- **44** — Dynamic-object lifetime and heap growth, duplicated inherited data, instance-specific breakpoints, transaction ordering and constraint-conflict debugging.

## Bibliographic and technical caveats

- **01:** PDF says SNUG 2000, despite upstream `snug99` filename. **03:** all three authors are Stuart Sutherland, Don Mills and Chris Spear.
- **04:** title page says DesignCon 2011; author URL/local filename say 2012. Definitive year remains unset. Original filename is preserved.
- **14:** author archive says 2009, but the author's 2015 SVA paper reference [10] calls the last-minute-assertions work DVCon 2013. The acquired PDF does not resolve that conflict; definitive year is unset and the source-derived 2009 filename is not a date assertion.
- **43:** acquired PDF lists three authors; the official archive additionally lists Brian Keng. Catalog follows the actual PDF and records the unresolved archive discrepancy.
- **18/19:** SNUG 1999 papers, revised in 2000. **20:** HDLCon 2002 Rev 1.2. **21b:** SNUG 2002 Rev 1.2 copy updated June 16, 2005. **37:** SNUG 1998 Rev 1.1.
- **10** remains the original presentation, not a full paper (31 physical handout pages; slide numbering is not the page count). No duplicate full-paper edition was added.
- **05/06** are retained research preprints; 06 is LLM-assisted lint research, not a replacement for deterministic lint. Papers 07/08 are research-oriented debugging methods. Other papers' case-study, performance and accuracy claims have not been independently replicated.
- Historical synthesis directives, early SystemVerilog syntax, OVM examples (34), UVM APIs and vendor commands require review against current standards/tools. Read the older FSM pragma discussion with papers 15/18. RTL simulation/assertions alone do not prove analog CDC safety.

## Acquisition, verification and preservation

New papers came from the author archive, official DVCon proceedings, MIT and UMBC university copies. Download receipts capture requested/resolved URL, retrieval UTC, HTTP/content type, bytes and SHA-256. Normal TLS verification was used; no paywalls/access controls were bypassed and no dependencies were installed. All acquisition and content processing evidence is local to `.curation/`.

All retained PDFs pass PDF-header/EOF checks and native Windows PDF parsing; native page counts and hashes agree with the manifest. Every new page object was opened, and title, second, middle and last pages were rendered/OCRed and reviewed (all three pages for 44). This is sampled content inspection, not exhaustive page rendering, a formal conformance check or replication.

Exact-hash and normalized-title checks found no retained duplicates; manual title/author/subject review excludes same-work/deck variants. All ten original PDFs and original `.curation` evidence remain byte-identical. Original metadata bytes were saved before replacement:

- [Original README snapshot](.curation/README-before-expansion-20261103T2250072236256Z.md)
- [Original manifest snapshot](.curation/manifest-before-expansion-20261103T2250072236256Z.json)
- [Preservation audit](.curation/expansion-preservation-audit.json)
- [Final native PDF/title evidence](.curation/expansion-final-pdf-validation.json)
- [New-paper body/title OCR evidence](.curation/expansion-content-inspection-01.json)
- [Reviewed bibliography, relevance and uncertainties](.curation/expansion-reviews.json)
- [Acquisition log, including failed attempts](.curation/expansion-acquisition-log.json)
- [Selection/rejection and same-work decisions](.curation/expansion-selection-decisions.json)

Failed/rejected sources include CMU TLS, SCU 404, Twente DNS, the moved Verilab PDF, unavailable archive listings and older-search pages. The former Sunburst paper archive resolves to an HTML technical-library landing page, not a PDF. The FIFO style #1 paper was acquired legitimately from UMBC instead. The unavailable FIFO style #2 and 2008 Cummings CDC paper were not substituted with unverified mirrors. Full CDC assertion and formal/MSI papers provide complementary depth.

The four-page SmartLint wrapper paper (candidate 29) was downloaded, fully inspected and removed for insufficient distinct detail; its receipt/OCR/rejection evidence is retained. Matching posters/decks and a presentation-only transaction-debug candidate were not acquired. The short paper 44 is retained for concrete dynamic-object and runtime-debug failure modes.

The collection is not a comprehensive commercial-linter administration/waiver-governance manual. Its deterministic guidance is distributed across coding semantics, overflow checks, assertion lint, AST-based testbench lint, coverage-model checks and CDC/RDC static methodology.

## Rights

Publicly accessible author, university or official conference copy, retained for local reading. Public availability is not a blanket redistribution license. Original PDF bytes and notices are retained; no collection-wide license or redistribution permission is asserted. Consult each source/rightsholder before sharing.
Source copyright notices remain inside unchanged PDF bytes. Do not treat this local index or public access as permission to redistribute the collection.
