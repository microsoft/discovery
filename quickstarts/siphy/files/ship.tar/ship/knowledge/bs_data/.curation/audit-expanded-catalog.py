"""Read-only consistency checks followed by a fresh, exclusive audit evidence file."""
import datetime
import hashlib
import json
import pathlib
import re
import unicodedata
from collections import Counter

ROOT = pathlib.Path(__file__).resolve().parent.parent
CURATION = ROOT / ".curation"


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    manifest = load(ROOT / "manifest.json")
    docs = manifest["documents"]
    actual = {str(p.relative_to(ROOT)).replace("\\", "/") for p in ROOT.rglob("*.pdf")}
    assert len(actual) == len(docs) == manifest["pdf_count"] == 40
    assert manifest["new_addition_count"] == 30 and len(actual) <= manifest["hard_pdf_cap"] == 50
    assert actual == {doc["file"] for doc in docs}
    native = {item["file"]: item for item in load(CURATION / "expansion-final-pdf-validation.json")}
    inspected = {item["file"]: item for item in load(CURATION / "expansion-content-inspection-01.json")}
    assert set(native) == actual
    hashes = []
    titles = []
    content_samples = 0
    results = []
    for doc in docs:
        path = ROOT / doc["file"]
        data = path.read_bytes()
        assert data.startswith(b"%PDF-") and b"%%EOF" in data[-4096:], path.name
        assert len(data) == doc["bytes"] == native[path.name]["bytes"], path.name
        actual_hash = hashlib.sha256(data).hexdigest()
        assert actual_hash == doc["sha256"] == native[path.name]["sha256"], path.name
        assert doc["pages"] == native[path.name]["pages"] > 0, path.name
        assert doc["title"] and doc["authors"] and doc["type"]
        assert doc["requested_url"].startswith("https://")
        for field in ("retrieved_utc", "resolved_url", "source_host_basis", "rights"):
            assert doc[field], (path.name, field)
        if doc["collection_status"] == "new_retained":
            assert doc["metadata_notes"]
            receipt = load(ROOT / doc["receipt"])
            assert receipt["sha256"] == actual_hash and receipt["pdf_header_and_eof"]
            sample = inspected[path.name]
            assert sample["all_page_objects_opened"] and sample["pages"] == doc["pages"]
            assert sample["sha256"] == actual_hash
            expected_samples = {1, 2, doc["pages"] // 2 + 1, doc["pages"]}
            assert {p["physical_page"] for p in sample["sampled_pages"]} == expected_samples
            content_samples += len(sample["sampled_pages"])
            assert doc["validation"]["sampled_content_reviewed"] and doc["content_checked"]
            evidence = doc.get("source_page_evidence")
            if evidence:
                for field in ("local_page", "receipt"):
                    assert (ROOT / evidence[field]).is_file()
                if "archive_bibliographic_text" in evidence:
                    source_receipt = load(ROOT / evidence["receipt"])
                    assert doc["requested_url"] in {link["url"] for link in source_receipt["links"]}
                    assert "Type: Paper" in evidence["archive_bibliographic_text"]
        hashes.append(actual_hash)
        titles.append(re.sub(r"[^a-z0-9]", "", unicodedata.normalize("NFKD", doc["title"]).casefold()))
        results.append({"file": path.name, "sha256_matches": True, "bytes_match": True,
                        "native_pages": doc["pages"], "header_eof": True})
    assert len(set(hashes)) == len(hashes)
    assert len(set(titles)) == len(titles)
    assert sum(d["pages"] for d in docs) == manifest["total_physical_pages"]
    assert sum(d["bytes"] for d in docs) == manifest["total_bytes"]
    counts = Counter(c for doc in docs for c in doc["coverage_categories"])
    assert dict(counts) == manifest["coverage_counts_nonexclusive"]

    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    local_links = [link for link in re.findall(r"\]\(([^)]+)\)", readme)
                   if not link.startswith(("https://", "http://"))]
    for link in local_links:
        assert (ROOT / link).is_file(), link
    assert {link for link in local_links if link.endswith(".pdf")} == actual
    originals = load(ROOT / manifest["original_preservation"]["manifest_snapshot"])["documents"]
    new_by_file = {d["file"]: d for d in docs}
    for old in originals:
        current = new_by_file[old["file"]]
        for field in ("title", "authors", "year", "venue", "type", "metadata_notes",
                      "requested_url", "resolved_url", "bytes", "sha256", "pages"):
            assert current.get(field) == old.get(field), (old["file"], field)
    baseline = load(ROOT / manifest["original_preservation"]["baseline"])
    preserved = load(CURATION / "expansion-preservation-audit.json")["original_files"]
    assert len(preserved) == len(baseline) == 30
    for item in preserved:
        assert sha(ROOT / item["preserved_at"]) == item["sha256"], item["preserved_at"]

    source_resources_checked = 0
    failures = 0
    for receipt_path in CURATION.glob("*-receipt.json"):
        receipt = load(receipt_path)
        if receipt["status"] == "failed_or_rejected":
            failures += 1
            assert receipt["error"] and receipt["retrieved_utc"] and receipt["requested_url"]
            continue
        resource = ROOT / receipt["file"]
        if resource.name == "29-smartlint-uvm-linting-2025.pdf":
            assert not resource.exists()
            continue
        assert resource.is_file() and sha(resource) == receipt["sha256"], resource.name
        assert resource.stat().st_size == receipt["bytes"]
        source_resources_checked += 1
    decisions = load(CURATION / "expansion-selection-decisions.json")
    assert set(decisions["retained_additions"]) == {
        d["file"] for d in docs if d["collection_status"] == "new_retained"}
    assert not (ROOT / decisions["rejected_after_content_review"][0]["file"]).exists()
    assert new_by_file["04-sutherland-systemverilog-fpga-design-2012.pdf"]["year"] is None
    assert new_by_file["01-cummings-nonblocking-assignments-2000.pdf"]["year"] == 2000
    assert len(new_by_file["03-sutherland-mills-gotcha-again-2007.pdf"]["authors"]) == 3
    report = {
        "audited_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "result": "pass",
        "pdf_count": len(docs),
        "new_additions": 30,
        "total_physical_pages": manifest["total_physical_pages"],
        "total_bytes": manifest["total_bytes"],
        "original_pdfs_byte_identical": 10,
        "original_provenance_files_byte_identical": 18,
        "original_metadata_snapshot_hashes_match": True,
        "retained_duplicate_hashes": 0,
        "retained_duplicate_normalized_titles": 0,
        "same_work_review": ".curation/expansion-selection-decisions.json",
        "local_readme_links_resolve": len(local_links),
        "new_paper_rendered_ocr_content_samples": content_samples,
        "acquired_resource_hashes_verified": source_resources_checked,
        "expansion_failed_source_attempts_recorded": failures,
        "topic_counts_nonexclusive": dict(counts),
        "files": results,
        "manifest_sha256": sha(ROOT / "manifest.json"),
        "readme_sha256": sha(ROOT / "README.md"),
        "limitations": "Content/title agreement is a recorded human-style sampled OCR review, not an automated proof of bibliography or scientific correctness. Authorship/year conflicts remain explicitly documented.",
    }
    with (CURATION / "expansion-final-audit.json").open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(json.dumps({key: value for key, value in report.items() if key != "files"}, indent=2))


if __name__ == "__main__":
    main()
