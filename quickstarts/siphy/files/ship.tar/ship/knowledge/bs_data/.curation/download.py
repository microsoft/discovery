"""Download public research PDFs without overwriting existing files."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import urllib.error
import urllib.request

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
parser = argparse.ArgumentParser()
parser.add_argument("ids", nargs="+")
options = parser.parse_args()
sources = json.loads((HERE / "sources.json").read_text(encoding="utf-8"))
failed = False
for source in sources:
    if source["id"] not in options.ids:
        continue
    target = ROOT / source["file"]
    receipt = HERE / (source["id"] + "-download.json")
    if target.exists() or receipt.exists():
        raise SystemExit(f"Refusing existing target or receipt for {source['id']}")
    result = dict(source)
    result["retrieved_utc"] = datetime.now(timezone.utc).isoformat()
    try:
        request = urllib.request.Request(source["url"], headers={
            "User-Agent": "Research-PDF-curation/1.0",
            "Accept": "application/pdf"
        })
        with urllib.request.urlopen(request, timeout=60) as response:
            data = response.read(32 * 1024 * 1024 + 1)
            result["resolved_url"] = response.geturl()
            result["content_type"] = response.headers.get("Content-Type")
            result["http_status"] = response.status
        if len(data) > 32 * 1024 * 1024:
            raise ValueError("PDF exceeds the explicit 32 MiB download limit")
        if not data.startswith(b"%PDF-"):
            raise ValueError("Response is not a PDF; refusing HTML/login/error content")
        if b"%%EOF" not in data[-4096:]:
            raise ValueError("PDF EOF marker missing; possible truncated response")
        if len(data) < 1024:
            raise ValueError("Implausibly small research PDF")
        with target.open("xb") as stream:
            stream.write(data)
        result.update(status="downloaded", bytes=len(data),
                      sha256=hashlib.sha256(data).hexdigest())
    except (urllib.error.URLError, TimeoutError, ValueError, OSError) as error:
        result.update(status="failed", error=f"{type(error).__name__}: {error}")
        failed = True
    with receipt.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2)
    print(json.dumps({key: value for key, value in result.items()
                      if key in ("id", "status", "bytes", "error", "resolved_url")}))
raise SystemExit(1 if failed else 0)
