"""Build the expanded catalog from preserved originals and reviewed local evidence."""
import collections
import copy
import datetime
import hashlib
import html
import json
import pathlib
import re
import unicodedata

ROOT = pathlib.Path(__file__).resolve().parent.parent
CURATION = ROOT / ".curation"
RIGHTS = ("Publicly accessible author, university or official conference copy, retained for local "
          "reading. Public availability is not a blanket redistribution license. Original PDF "
          "bytes and notices are retained; no collection-wide license or redistribution permission "
          "is asserted. Consult each source/rightsholder before sharing.")
CATEGORIES = {
    "RTL coding": "RTL",
    "Deterministic lint/static analysis": "LINT",
    "Functional simulation/testbench design": "TB",
    "Assertions": "SVA",
    "Coverage/constrained-random verification": "COV",
    "CDC": "CDC",
    "Reset/RDC": "RST",
    "FIFO design/modeling": "FIFO",
    "Verification-failure debugging": "DBG",
    "Static-analysis research (not deterministic-lint guidance)": "RESEARCH",
}
ORIGINAL_CATEGORIES = {
    "01": ["RTL coding", "Deterministic lint/static analysis", "Functional simulation/testbench design"],
    "02": ["Functional simulation/testbench design", "Verification-failure debugging"],
    "03": ["RTL coding", "Deterministic lint/static analysis", "Functional simulation/testbench design",
           "Verification-failure debugging"],
    "04": ["RTL coding"],
    "05": ["Static-analysis research (not deterministic-lint guidance)"],
    "06": ["Static-analysis research (not deterministic-lint guidance)"],
    "07": ["Verification-failure debugging"],
    "08": ["Verification-failure debugging"],
    "09": ["RTL coding", "Deterministic lint/static analysis", "Reset/RDC"],
    "10": ["RTL coding"],
}


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_new(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=True)
        stream.write("\n")


def normalized_title(title):
    title = unicodedata.normalize("NFKD", title).casefold()
    return re.sub(r"[^a-z0-9]", "", title)


def source_page_info(stem):
    receipt = load(CURATION / (stem + "-receipt.json"))
    text = (CURATION / (stem + ".html")).read_text(encoding="utf-8")
    article = re.search(r"<article\b.*?</article>", text, re.S)
    if not article:
        raise ValueError(f"No article in {stem}")
    visible = html.unescape(re.sub(r"<[^>]+>", " ", article.group()))
    visible = re.sub(r"\s+", " ", visible).strip()
    return {
        "url": receipt["requested_url"],
        "resolved_url": receipt["resolved_url"],
        "local_page": ".curation/" + stem + ".html",
        "receipt": ".curation/" + stem + "-receipt.json",
        "archive_bibliographic_text": visible,
    }


def main():
    original_snapshot = next(CURATION.glob("manifest-before-expansion-*.json"))
    readme_snapshot = next(CURATION.glob("README-before-expansion-*.md"))
    baseline_path = next(CURATION.glob("original-baseline-*.json"))
    original = load(original_snapshot)
    assert original["pdf_count"] == 10
    reviews = load(CURATION / "expansion-reviews.json")
    validation = load(CURATION / "expansion-final-pdf-validation.json")
    inspected = load(CURATION / "expansion-content-inspection-01.json")
    native = {item["file"]: item for item in validation}
    content = {item["file"]: item for item in inspected}
    source_stems = {}
    for candidate_list in ("expansion-dvcon-candidates.json", "expansion-final-candidates.json"):
        source_stems.update(dict(load(CURATION / candidate_list)))
    source_stems.update({
        "38-sva-cdc-data-paths-2015.pdf": "cdc-assertions-landing",
        "39-pragmatic-formal-cdc-2023.pdf": "cdc-formal-landing",
    })
    documents = copy.deepcopy(original["documents"])
    for doc in documents:
        doc["coverage_categories"] = ORIGINAL_CATEGORIES[doc["file"][:2]]
        doc["collection_status"] = "original_preserved"
        doc["validation"]["full_collection_recheck"] = ".curation/expansion-final-pdf-validation.json"
    for review in reviews["documents"]:
        matches = list(ROOT.glob(review["id"] + "-*.pdf"))
        assert len(matches) == 1, (review["id"], matches)
        path = matches[0]
        receipt_path = CURATION / (path.stem + "-receipt.json")
        receipt = load(receipt_path)
        checked = native[path.name]
        samples = content[path.name]
        actual_hash = digest(path)
        assert actual_hash == receipt["sha256"] == checked["sha256"] == samples["sha256"]
        assert path.stat().st_size == receipt["bytes"] == checked["bytes"] == samples["bytes"]
        assert checked["pages"] == samples["pages"] and samples["all_page_objects_opened"]
        assert receipt["pdf_header_and_eof"]
        doc = {key: copy.deepcopy(review[key]) for key in
               ("title", "authors", "year", "venue", "metadata_notes", "relevance", "content_checked")}
        doc.update({
            "file": path.name,
            "type": "Practitioner technical conference paper",
            "collection_status": "new_retained",
            "coverage_categories": review["categories"],
            "topics": review["categories"],
            "requested_url": receipt["requested_url"],
            "resolved_url": receipt["resolved_url"],
            "retrieved_utc": receipt["retrieved_utc"],
            "source_host_basis": receipt["source_host_basis"],
            "http_status": receipt["http_status"],
            "content_type": receipt["content_type"],
            "bytes": receipt["bytes"],
            "sha256": actual_hash,
            "pages": checked["pages"],
            "receipt": str(receipt_path.relative_to(ROOT)).replace("\\", "/"),
            "rights": RIGHTS,
            "validation": {
                "pdf_header_and_eof": True,
                "native_parser": checked["parser"],
                "first_page_rendered": True,
                "first_page_ocr_reviewed": True,
                "all_page_objects_opened": True,
                "sampled_physical_pages": [p["physical_page"] for p in samples["sampled_pages"]],
                "sampled_content_reviewed": True,
                "evidence": ".curation/expansion-final-pdf-validation.json",
                "content_evidence": ".curation/expansion-content-inspection-01.json",
                "bibliographic_review": ".curation/expansion-reviews.json",
                "limitation": "Native parsing and sampled rendering/OCR, not exhaustive rendering or independent technical replication.",
            },
        })
        if path.name in source_stems:
            doc["source_page_evidence"] = source_page_info(source_stems[path.name])
            doc["metadata_url"] = doc["source_page_evidence"]["url"]
            archive_text = doc["source_page_evidence"]["archive_bibliographic_text"]
            assert f"Year: {doc['year']}" in archive_text and "Type: Paper" in archive_text
        elif "sutherland-hdl.com" in receipt["requested_url"]:
            doc["metadata_url"] = "https://sutherland-hdl.com/papers"
            doc["source_page_evidence"] = {
                "local_page": ".curation/sutherland-source.html",
                "receipt": ".curation/sutherland-source-receipt.json",
            }
        elif "csg.csail.mit.edu" in receipt["requested_url"]:
            doc["metadata_url"] = "https://csg.csail.mit.edu/6.375/6_375_2007_www/papers/"
            doc["source_page_evidence"] = {
                "local_page": ".curation/mit-source.html",
                "receipt": ".curation/mit-source-receipt.json",
            }
        else:
            doc["metadata_url"] = None
        documents.append(doc)

    documents.sort(key=lambda item: item["file"])
    actual_files = {p.name for p in ROOT.rglob("*.pdf")}
    assert len(documents) == len(actual_files) <= 50
    assert {doc["file"] for doc in documents} == actual_files
    assert len({doc["sha256"] for doc in documents}) == len(documents)
    assert len({normalized_title(doc["title"]) for doc in documents}) == len(documents)
    for doc in documents:
        path = ROOT / doc["file"]
        assert digest(path) == doc["sha256"] == native[path.name]["sha256"]
        assert path.stat().st_size == doc["bytes"] == native[path.name]["bytes"]
        assert native[path.name]["pages"] == doc["pages"]

    preserved = []
    for entry in load(baseline_path):
        relative = entry["file"].replace("\\", "/")
        if relative == "README.md":
            path = readme_snapshot
        elif relative == "manifest.json":
            path = original_snapshot
        else:
            path = ROOT / entry["file"]
        assert path.is_file() and digest(path) == entry["sha256"], relative
        assert path.stat().st_size == entry["bytes"], relative
        preserved.append({
            "original_path": relative,
            "preserved_at": str(path.relative_to(ROOT)).replace("\\", "/"),
            "sha256": entry["sha256"],
            "unchanged": True,
        })

    receipts = []
    failures = []
    for path in sorted(CURATION.glob("*-receipt.json")):
        receipt = load(path)
        receipts.append({"receipt": ".curation/" + path.name, **receipt})
        if receipt["status"] == "failed_or_rejected":
            failures.append({"receipt": ".curation/" + path.name, **receipt})
    variant_decisions = []
    for path in sorted(CURATION.glob("*landing*.html")):
        text = path.read_text(encoding="utf-8")
        match = re.search(r"<article[^>]*document_type-(presentation|poster)", text)
        if match:
            variant_decisions.append({
                "landing_page": ".curation/" + path.name,
                "source": load(CURATION / (path.stem + "-receipt.json"))["requested_url"],
                "decision": "not_acquired",
                "reason": f"Archive classifies this as {match.group(1)}; full papers prioritized and redundant variants excluded.",
            })
    decisions = {
        "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "retained_additions": [doc["file"] for doc in documents if doc["collection_status"] == "new_retained"],
        "rejected_after_content_review": reviews["rejected_downloads"],
        "nonpaper_variants_not_acquired": variant_decisions,
        "other_decisions": [
            {
                "url": "https://sutherland-hdl.com/papers/2013-SNUG-SV_Synthesizable-SystemVerilog_paper.pdf",
                "decision": "not_acquired",
                "reason": "Same work as preserved presentation 10; no compelling distinct contribution established for adding a paper/deck duplicate.",
            },
            {
                "url": "https://www.sunburst-design.com/papers/",
                "decision": "not_a_pdf_source",
                "reason": "Normal redirect resolves to paradigm-works.com/technical-library HTML with login/registration links and no PDF hrefs. No access-control bypass attempted.",
                "evidence": ".curation/sunburst-redirect-source-receipt.json",
            },
            {
                "decision": "search_narratives_not_bibliographic_evidence",
                "reason": "Search narratives supplied unverified CDC university leads that failed TLS, DNS or HTTP. Only directly downloaded, content-reviewed sources support retained-paper bibliography.",
            },
        ],
        "limitations_and_stopping_basis": reviews["selection_limitations"],
        "same_work_review": [
            "Paper 15 covers SystemVerilog unique/priority; 18 covers older Verilog synthesis pragmas. Complementary, not the same publication.",
            "Paper 11 is embedded RTL assertion guidance; 14 is a project-specific late-assertion case study.",
            "Paper 16 is interface/FIFO-channel modeling; 21b is a concrete asynchronous CDC FIFO implementation.",
            "Papers 35 and 36 address RDC methodology and reset-tree/noise-analysis respectively.",
            "Papers 40, 41 and 42 cover coverage planning, static correctness and multi-cross hole debugging respectively.",
            "No new paper/presentation pair retained; title/author/subject review supplements exact-hash and normalized-title checks.",
        ],
    }
    counts = collections.Counter(category for doc in documents for category in doc["coverage_categories"])
    manifest = copy.deepcopy(original)
    manifest.update({
        "expanded_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "pdf_count": len(documents),
        "original_pdf_count": 10,
        "new_addition_count": len(documents) - 10,
        "total_physical_pages": sum(doc["pages"] for doc in documents),
        "total_bytes": sum(doc["bytes"] for doc in documents),
        "hard_pdf_cap": 50,
        "scope": "Advanced practical RTL coding, deterministic lint/static analysis, simulation/testbenches, assertions, coverage/constrained random, CDC/reset/FIFO design and failure debugging.",
        "bookshelf_ingested": False,
        "documents": documents,
        "coverage_counts_nonexclusive": dict(counts),
        "coverage_counting_notes": "Categories are nonexclusive, subject-based catalog tags, not quality scores. Original research preprints 05/06 are separated from deterministic-lint guidance.",
        "rights": RIGHTS,
        "selection_limitations": reviews["selection_limitations"],
        "validation_scope": reviews["review_method"],
        "original_preservation": {
            "baseline": str(baseline_path.relative_to(ROOT)).replace("\\", "/"),
            "readme_snapshot": str(readme_snapshot.relative_to(ROOT)).replace("\\", "/"),
            "manifest_snapshot": str(original_snapshot.relative_to(ROOT)).replace("\\", "/"),
            "original_pdfs_byte_identical": 10,
            "original_evidence_files_byte_identical": sum(p["original_path"].startswith(".curation/") for p in preserved),
            "audit": ".curation/expansion-preservation-audit.json",
        },
        "expansion_evidence": {
            "acquisition_log": ".curation/expansion-acquisition-log.json",
            "selection_decisions": ".curation/expansion-selection-decisions.json",
            "bibliographic_reviews": ".curation/expansion-reviews.json",
            "native_final_validation": ".curation/expansion-final-pdf-validation.json",
            "sampled_content_inspection": ".curation/expansion-content-inspection-01.json",
        },
        "expansion_failed_or_rejected_source_attempts": failures,
    })
    write_new(CURATION / "expansion-preservation-audit.json", {
        "created_utc": manifest["expanded_utc"], "original_files": preserved,
        "result": "All original PDF/evidence hashes unchanged; original README/manifest bytes preserved in uniquely named snapshots.",
    })
    write_new(CURATION / "expansion-selection-decisions.json", decisions)
    write_new(CURATION / "expansion-acquisition-log.json", {
        "created_utc": manifest["expanded_utc"], "receipts": receipts,
        "note": "Receipts are immutable acquisition-time records. Pending-review status is historical; final retention/rejection is recorded in selection decisions and manifest.",
    })

    lines = [
        "# Local RTL design and verification reading collection", "",
        f"**{len(documents)} local PDFs: 10 originals + {len(documents)-10} additions; "
        f"{manifest['total_physical_pages']} physical pages. Hard cap: 50, including originals.**",
        "",
        "A practitioner-oriented collection of substantial technical/conference papers, with the original "
        "research preprints and presentation retained. No dissertations, new slide decks, textbook copies, "
        "Bookshelf ingestion or engineering deliverables were added. Stopping is based on complementary "
        "coverage/source quality, not a quota.",
        "",
        "## Coverage", "",
        "Counts are **nonexclusive**: a document can contribute to several topics. Tags indicate subject "
        "matter, not independently established effectiveness. FIFO includes a channel-modeling paper "
        "(16) and an actual asynchronous RTL implementation (21b).",
        "", "| Tag | Subject | PDFs |", "| --- | --- | ---: |",
    ]
    for category, abbreviation in CATEGORIES.items():
        lines.append(f"| {abbreviation} | {category} | {counts[category]} |")
    lines.extend([
        "",
        "Practical routes: RTL/lint 01, 03, 15, 18-20, 27, 37; deterministic verification lint 26, 28, 41; "
        "simulation/X/DPI/UVM 02, 12, 13, 16, 17, 25, 32, 44; assertions 11, 14, 26, 38; "
        "coverage/randomization 30-33, 40-42; CDC/FIFO 21b, 38, 39; reset/RDC 09, 34-36; "
        "failure localization/triage 07, 08, 43, plus the topic-specific debugging papers.",
        "",
        "## Full local index", "",
        "P = practitioner technical/conference paper; R = research paper; PP = preprint; "
        "S = presentation. Every title links to the actual local PDF. Source URLs below identify "
        "the acquired copy; original/resolved URLs, timestamps, bytes, SHA-256, native page counts, "
        "host basis, rights and evidence paths are in [manifest.json](manifest.json).",
        "", "| ID | Actual title / local PDF | Authors; year | Kind; pages | Topics | Source |",
        "| --- | --- | --- | --- | --- | --- |",
    ])
    for doc in documents:
        title = doc["title"].replace("|", "\\|")
        authors = ", ".join(doc["authors"])
        year = str(doc["year"]) if doc["year"] is not None else "unresolved"
        kind = ("PP" if "preprint" in doc["type"].lower() else
                "S" if "presentation" in doc["type"].lower() else
                "R" if "research" in doc["type"].lower() else "P")
        topics = ", ".join(CATEGORIES[c] for c in doc["coverage_categories"])
        lines.append(f"| {doc['file'].split('-')[0]} | [{title}]({doc['file']}) | "
                     f"{authors}; {year} | {kind}; {doc['pages']} | {topics} | "
                     f"[source]({doc['requested_url']}) |")
    lines.extend(["", "## Distinct practical contribution of each addition", ""])
    for doc in documents:
        if doc["collection_status"] == "new_retained":
            lines.append(f"- **{doc['file'].split('-')[0]}** — {doc['relevance']}")
    lines.extend([
        "",
        "## Bibliographic and technical caveats", "",
        "- **01:** PDF says SNUG 2000, despite upstream `snug99` filename. **03:** all three authors "
        "are Stuart Sutherland, Don Mills and Chris Spear.",
        "- **04:** title page says DesignCon 2011; author URL/local filename say 2012. Definitive year "
        "remains unset. Original filename is preserved.",
        "- **14:** author archive says 2009, but the author's 2015 SVA paper reference [10] calls the "
        "last-minute-assertions work DVCon 2013. The acquired PDF does not resolve that conflict; "
        "definitive year is unset and the source-derived 2009 filename is not a date assertion.",
        "- **43:** acquired PDF lists three authors; the official archive additionally lists Brian Keng. "
        "Catalog follows the actual PDF and records the unresolved archive discrepancy.",
        "- **18/19:** SNUG 1999 papers, revised in 2000. **20:** HDLCon 2002 Rev 1.2. "
        "**21b:** SNUG 2002 Rev 1.2 copy updated June 16, 2005. **37:** SNUG 1998 Rev 1.1.",
        "- **10** remains the original presentation, not a full paper (31 physical handout pages; "
        "slide numbering is not the page count). No duplicate full-paper edition was added.",
        "- **05/06** are retained research preprints; 06 is LLM-assisted lint research, not a replacement "
        "for deterministic lint. Papers 07/08 are research-oriented debugging methods. Other papers' "
        "case-study, performance and accuracy claims have not been independently replicated.",
        "- Historical synthesis directives, early SystemVerilog syntax, OVM examples (34), UVM APIs "
        "and vendor commands require review against current standards/tools. Read the older FSM pragma "
        "discussion with papers 15/18. RTL simulation/assertions alone do not prove analog CDC safety.",
        "",
        "## Acquisition, verification and preservation", "",
        "New papers came from the author archive, official DVCon proceedings, MIT and UMBC university "
        "copies. Download receipts capture requested/resolved URL, retrieval UTC, HTTP/content type, "
        "bytes and SHA-256. Normal TLS verification was used; no paywalls/access controls were bypassed "
        "and no dependencies were installed. All acquisition and content processing evidence is local "
        "to `.curation/`.",
        "",
        "All retained PDFs pass PDF-header/EOF checks and native Windows PDF parsing; native page counts "
        "and hashes agree with the manifest. Every new page object was opened, and title, second, middle "
        "and last pages were rendered/OCRed and reviewed (all three pages for 44). This is sampled "
        "content inspection, not exhaustive page rendering, a formal conformance check or replication.",
        "",
        "Exact-hash and normalized-title checks found no retained duplicates; manual title/author/subject "
        "review excludes same-work/deck variants. All ten original PDFs and original `.curation` evidence "
        "remain byte-identical. Original metadata bytes were saved before replacement:",
        "",
        f"- [Original README snapshot]({manifest['original_preservation']['readme_snapshot']})",
        f"- [Original manifest snapshot]({manifest['original_preservation']['manifest_snapshot']})",
        "- [Preservation audit](.curation/expansion-preservation-audit.json)",
        "- [Final native PDF/title evidence](.curation/expansion-final-pdf-validation.json)",
        "- [New-paper body/title OCR evidence](.curation/expansion-content-inspection-01.json)",
        "- [Reviewed bibliography, relevance and uncertainties](.curation/expansion-reviews.json)",
        "- [Acquisition log, including failed attempts](.curation/expansion-acquisition-log.json)",
        "- [Selection/rejection and same-work decisions](.curation/expansion-selection-decisions.json)",
        "",
        "Failed/rejected sources include CMU TLS, SCU 404, Twente DNS, the moved Verilab PDF, unavailable "
        "archive listings and older-search pages. The former Sunburst paper archive resolves to an HTML "
        "technical-library landing page, not a PDF. The FIFO style #1 paper was acquired legitimately "
        "from UMBC instead. The unavailable FIFO style #2 and 2008 Cummings CDC paper were not substituted "
        "with unverified mirrors. Full CDC assertion and formal/MSI papers provide complementary depth.",
        "",
        "The four-page SmartLint wrapper paper (candidate 29) was downloaded, fully inspected and removed "
        "for insufficient distinct detail; its receipt/OCR/rejection evidence is retained. Matching "
        "posters/decks and a presentation-only transaction-debug candidate were not acquired. The short "
        "paper 44 is retained for concrete dynamic-object and runtime-debug failure modes.",
        "",
        "The collection is not a comprehensive commercial-linter administration/waiver-governance manual. "
        "Its deterministic guidance is distributed across coding semantics, overflow checks, assertion "
        "lint, AST-based testbench lint, coverage-model checks and CDC/RDC static methodology.",
        "",
        "## Rights", "",
        RIGHTS,
        "Source copyright notices remain inside unchanged PDF bytes. Do not treat this local index or "
        "public access as permission to redistribute the collection.",
        "",
    ])
    rendered = "\n".join(lines)
    for target in re.findall(r"\]\(([^)]+)\)", rendered):
        if not target.startswith(("https://", "http://")):
            assert (ROOT / target).is_file(), target
    # Metadata replacement is explicitly authorized; the original versions are already audited above.
    (ROOT / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")
    (ROOT / "README.md").write_text(rendered, encoding="utf-8")
    print(json.dumps({
        "pdf_count": len(documents), "new_additions": len(documents) - 10,
        "physical_pages": manifest["total_physical_pages"], "bytes": manifest["total_bytes"],
        "original_pdf_hashes_preserved": 10,
        "original_evidence_hashes_preserved": manifest["original_preservation"]["original_evidence_files_byte_identical"],
        "nonexclusive_topic_counts": dict(counts),
    }, indent=2))


if __name__ == "__main__":
    main()
