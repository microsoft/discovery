# Advanced RTL and verification reading collection

This collection contains **10 PDFs, 258 physical pages**: two research preprints,
one research conference paper, one research journal manuscript, five advanced
practitioner conference papers, and one technical presentation. It combines
research-level analysis/debugging methods with foundational engineering guidance.
It is not a collection of ten doctoral dissertations, and the practitioner papers
should not be described as peer-reviewed journal research.

## Reading index

| PDF | Citation and classification | Relevance |
|---|---|---|
| [01 - Nonblocking assignments](01-cummings-nonblocking-assignments-2000.pdf) | Clifford E. Cummings. *Nonblocking Assignments in Verilog Synthesis, Coding Styles That Kill!* SNUG San Jose, 2000. Advanced practitioner paper; 23 pages. [University source](https://csg.csail.mit.edu/6.375/6_375_2007_www/papers/cummings-nonblocking-snug99.pdf). | Scheduling semantics, sequential/combinational modeling, race avoidance, and the technical rationale behind assignment-style lint rules. |
| [02 - Event regions and race avoidance](02-cummings-systemverilog-event-regions-2006.pdf) | Clifford E. Cummings and Arturo Salz. *SystemVerilog Event Regions, Race Avoidance & Guidelines*. SNUG Boston, 2006. Advanced practitioner paper; 42 pages. [University source](https://rfsoc.mit.edu/6S965/_static/F25/lectures/CummingsSNUG2006Boston_SystemVerilog_Events.pdf). | Testbench sampling/driving, simulator event regions, assertion scheduling, and simulation race diagnosis. |
| [03 - Gotcha Again](03-sutherland-mills-gotcha-again-2007.pdf) | Stuart Sutherland, Don Mills, and Chris Spear. *Gotcha Again: More Subtleties in the Verilog and SystemVerilog Standards That Every Engineer Should Know*. SNUG San Jose, 2007. Advanced practitioner paper; 44 pages. [Author source](https://sutherland-hdl.com/papers/2007-SNUG-SanJose_gotcha_again_paper.pdf). | Language corner cases that motivate coding checks: unexpected expression behavior, simulation mismatches, and subtle RTL defects. |
| [04 - SystemVerilog for FPGA design](04-sutherland-systemverilog-fpga-design-2012.pdf) | Stuart Sutherland. *What, If Anything, In SystemVerilog Will Help Me With FPGA-based Designs?* DesignCon; year discrepancy described below. Advanced practitioner paper; 18 pages. [Author source](https://sutherland-hdl.com/papers/2012-DesignCon_SV-for-FPGAs_paper.pdf). | Practical synthesizable SystemVerilog constructs and stronger RTL modeling. Tool support must be checked against current versions. |
| [05 - Qihe static-analysis framework](05-qihe-verilog-static-analysis-2026.pdf) | Qinlin Chen and eight coauthors; full author list in the manifest. *Qihe: A General-Purpose Static Analysis Framework for Verilog*. arXiv:2601.11408, 2026. Research preprint; 34 pages. [Repository record](https://arxiv.org/abs/2601.11408). | Analysis-oriented intermediate representations and hardware-specific static analyses; useful for understanding capabilities beyond syntactic lint. |
| [06 - LintLLM](06-lintllm-verilog-linting-2025.pdf) | Zhigang Fang, Renzhi Chen, Zhijie Yang, Yang Guo, Huadong Dai, and Lei Wang. *LintLLM: An Open-Source Verilog Linting Framework Based on Large Language Models*. arXiv:2502.10815, 2025. Research preprint; 7 pages. [Repository record](https://arxiv.org/abs/2502.10815). | Experimental lint-defect detection, mutation-based evaluation, and false-positive handling. Research supplement, not a normative lint policy or replacement for deterministic checks. |
| [07 - Maximum-satisfiability debugging](07-improved-design-debugging-maxsat-2007.pdf) | Sean Safarpour, Hratch Mangassarian, Andreas Veneris, Mark H. Liffiton, and Karem A. Sakallah. *Improved Design Debugging using Maximum Satisfiability*. FMCAD, 2007. Research conference paper; 7 pages. [Coauthor source](https://markliffiton.com/publications/fmcad07_safarpour_debugging.pdf). | Formal fault localization, suspect reduction, and the distinction between candidate explanations and actual root causes. |
| [08 - Structural-dominance RTL debugging](08-debugging-rtl-structural-dominance-2013.pdf) | Hratch Mangassarian, Bao Le, and Andreas Veneris. *Debugging RTL using Structural Dominance*. IEEE Transactions on Computer-Aided Design of Integrated Circuits and Systems, 2013. Author-hosted research journal manuscript; 14 pages. [University source](https://www.eecg.utoronto.ca/~veneris/13tcad2.pdf). | Advanced SAT-based RTL debugging, structural reasoning, and reducing formal-engine calls during error localization. |
| [09 - Reset design techniques](09-reset-design-techniques-part-deux-2003.pdf) | Clifford E. Cummings, Don Mills, and Steve Golson. *Asynchronous & Synchronous Reset Design Techniques - Part Deux*. SNUG Boston, 2003. Advanced practitioner paper; 38 pages. [Coauthor source](https://www.trilobyte.com/pdf/CummingsSNUG2003Boston_Resets_rev1_2.pdf). | Reset architecture tradeoffs, implementation hazards, and the reasoning behind reset-related coding and verification checks. |
| [10 - Synthesizing SystemVerilog](10-synthesizing-systemverilog-2013-slides.pdf) | Stuart Sutherland and Don Mills. *Synthesizing SystemVerilog: Busting the Myth that SystemVerilog is only for Verification*. SNUG Silicon Valley, 2013. Technical slide handout; 31 PDF pages, not the full paper. [Author source](https://sutherland-hdl.com/papers/2013-SNUG-SV_Synthesizable-SystemVerilog_presentation.pdf). | Synthesis-oriented language features and RTL coding practices; historical tool-support claims need present-day confirmation. |

## Suggested reading paths

- **RTL and lint best practices:** 01, 03, 09, then 04 and 10.
- **Functional simulation and race debugging:** 01, 02, then 03.
- **Graduate/research-level static analysis:** 05; compare 06 critically rather
  than adopting its evaluation claims as established facts.
- **Automated error localization:** 07, then 08.

These are grounding references, not permission to change a design's required
behavior or disable tool rules. A clean lint result is not proof of functional
correctness. Style, simulation, synthesis and formal evidence remain distinct.
The collection does not yet include a dedicated modern coverage-driven
verification textbook, complete UVM reference, or current normative language
standard.

## Provenance and limitations

- [Machine-readable manifest](manifest.json) records source and resolved URLs,
  retrieval timestamps, sizes, page counts, SHA-256 hashes, classifications,
  full author lists and metadata caveats.
- Each PDF was downloaded from an author, university or scholarly repository,
  checked for PDF header/trailer, opened with the installed Windows PDF parser,
  and had its first page rendered and OCR-reviewed. This establishes readable
  local PDF copies; it is not an independent replication of the papers' results.
- **Metadata corrections:** 01 says SNUG-2000 on its title page despite `snug99`
  in the upstream filename. 03 has three authors, including Chris Spear.
  **04 has an unresolved year conflict:** its title page says DesignCon 2011,
  while the author archive URL and retained filename say 2012. The manifest
  deliberately leaves its definitive year unset.
- The University of Florida copy of 02 failed TLS certificate verification.
  The collection instead uses an MIT-hosted copy. TLS verification was not
  disabled; the failed attempt remains in the manifest.
- Older papers are valuable for semantics and failure modes, but are not
  current tool-support matrices or substitutes for the language standard and
  current lint-rule documentation. Research preprints are labeled as such.
- Public download availability is **not** a blanket open license. Preserve
  each document's copyright notices and consult its applicable rights before
  redistribution. No paywall or access restriction was bypassed.
- The PDFs are saved locally; **no Bookshelf creation or ingestion was performed**.

Supporting download receipts, bibliographic records, native-parser/OCR evidence
and reproducibility scripts are retained in `.curation/`. That subdirectory and
this index can be excluded when ingesting only the PDFs into a Bookshelf.
