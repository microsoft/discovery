"""Standard-library acquisition with immutable receipts and normal TLS verification."""
import argparse
import datetime
import hashlib
import html.parser
import json
import pathlib
import urllib.error
import urllib.parse
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parent.parent


class Links(html.parser.HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
        self.current = None

    def handle_starttag(self, tag, attrs):
        if tag == "a":
            href = dict(attrs).get("href")
            self.current = [href, ""] if href else None

    def handle_data(self, data):
        if self.current:
            self.current[1] += data

    def handle_endtag(self, tag):
        if tag == "a" and self.current:
            self.links.append(self.current)
            self.current = None


def fetch(url, name, basis, pdf=False):
    destination = ROOT / (name if pdf else ".curation/" + name)
    receipt = ROOT / ".curation" / (destination.stem + "-receipt.json")
    if destination.exists() or receipt.exists():
        raise FileExistsError(f"Refusing overwrite: {destination} / {receipt}")
    record = dict(requested_url=url, source_host_basis=basis,
                  retrieved_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  file=str(destination.relative_to(ROOT)).replace("\\", "/"))
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "LocalLiteratureCuration/1.0"})
        with urllib.request.urlopen(request, timeout=60) as response:
            data = response.read(40 * 1024 * 1024 + 1)
            record.update(resolved_url=response.url, http_status=response.status,
                          content_type=response.headers.get("Content-Type"),
                          bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
        if len(data) > 40 * 1024 * 1024:
            raise ValueError("Resource exceeds 40 MiB limit")
        if pdf:
            if not data.startswith(b"%PDF-") or b"%%EOF" not in data[-4096:]:
                raise ValueError("Not a complete PDF: header/EOF check failed")
            if len(list(ROOT.glob("*.pdf"))) >= 50:
                raise ValueError("50-PDF hard cap")
            digest = record["sha256"]
            for existing in ROOT.glob("*.pdf"):
                if hashlib.sha256(existing.read_bytes()).hexdigest() == digest:
                    raise ValueError(f"Duplicate bytes of {existing.name}")
            record["pdf_header_and_eof"] = True
        destination.write_bytes(data)
        record["status"] = "downloaded_pending_content_review" if pdf else "source_page_captured"
        if not pdf:
            parser = Links()
            parser.feed(data.decode("utf-8", errors="replace"))
            record["links"] = [
                {"url": urllib.parse.urljoin(record["resolved_url"], href), "text": text.strip()}
                for href, text in parser.links
            ]
    except (urllib.error.URLError, TimeoutError, ValueError, OSError) as exc:
        record.update(status="failed_or_rejected", error=f"{type(exc).__name__}: {exc}")
    receipt.write_text(json.dumps(record, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in record.items() if key != "links"}, ensure_ascii=True))
    return record


if __name__ == "__main__":
    args = argparse.ArgumentParser()
    args.add_argument("url")
    args.add_argument("name")
    args.add_argument("basis")
    args.add_argument("--pdf", action="store_true")
    options = args.parse_args()
    fetch(options.url, options.name, options.basis, options.pdf)
