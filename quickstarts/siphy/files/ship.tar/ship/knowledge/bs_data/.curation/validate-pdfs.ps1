param(
    [string]$Filter = '*.pdf',
    [string]$EvidenceName = 'pdf-validation.json'
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime]
$null = [Windows.Data.Pdf.PdfDocument,Windows.Data.Pdf,ContentType=WindowsRuntime]
$null = [Windows.Storage.Streams.InMemoryRandomAccessStream,Windows.Storage.Streams,ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder,Windows.Graphics.Imaging,ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.SoftwareBitmap,Windows.Graphics.Imaging,ContentType=WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine,Windows.Media.Ocr,ContentType=WindowsRuntime]
$null = [Windows.Media.Ocr.OcrResult,Windows.Media.Ocr,ContentType=WindowsRuntime]
$operationTask = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and
    $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
} | Select-Object -First 1
$actionTask = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and -not $_.IsGenericMethod -and
    $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction'
} | Select-Object -First 1
function Await-Operation($Operation, [Type]$Type) {
    $task = $operationTask.MakeGenericMethod($Type).Invoke($null, @($Operation))
    $task.Wait()
    return $task.Result
}
function Await-Action($Action) {
    $task = $actionTask.Invoke($null, @($Action))
    $task.Wait()
}
$root = Split-Path $PSScriptRoot -Parent
$engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
if ($null -eq $engine) { throw 'No installed OCR language; PDF validation can run but title-page OCR cannot' }
$results = @()
foreach ($file in Get-ChildItem -LiteralPath $root -Filter $Filter -File | Sort-Object Name) {
    $storage = Await-Operation ([Windows.Storage.StorageFile]::GetFileFromPathAsync($file.FullName)) ([Windows.Storage.StorageFile])
    $pdf = Await-Operation ([Windows.Data.Pdf.PdfDocument]::LoadFromFileAsync($storage)) ([Windows.Data.Pdf.PdfDocument])
    if ($pdf.PageCount -lt 1) { throw "No pages in $($file.Name)" }
    $page = $pdf.GetPage(0)
    $stream = New-Object Windows.Storage.Streams.InMemoryRandomAccessStream
    $options = New-Object Windows.Data.Pdf.PdfPageRenderOptions
    $options.DestinationWidth = 1400
    Await-Action ($page.RenderToStreamAsync($stream, $options))
    $decoder = Await-Operation ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $bitmap = Await-Operation ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
    $ocr = Await-Operation ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
    $results += [pscustomobject]@{
        file = $file.Name
        pages = $pdf.PageCount
        bytes = $file.Length
        sha256 = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        parser = 'Windows.Data.Pdf.PdfDocument'
        title_page_ocr = $ocr.Text
        ocr_language = $engine.RecognizerLanguage.LanguageTag
    }
    Write-Output "$($file.Name): pages=$($pdf.PageCount)"
    $bitmap.Dispose()
    $stream.Dispose()
    $page.Dispose()
}
$output = Join-Path $PSScriptRoot $EvidenceName
if (Test-Path $output) { throw "Refusing existing validation evidence: $output" }
$json = ConvertTo-Json -InputObject @($results) -Depth 5
[IO.File]::WriteAllText($output, $json, (New-Object Text.UTF8Encoding($false)))
