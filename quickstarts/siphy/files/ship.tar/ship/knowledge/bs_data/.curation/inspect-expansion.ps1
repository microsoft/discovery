param([string]$EvidenceName = 'expansion-content-inspection.json')
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Storage.StorageFile,Windows.Storage,ContentType=WindowsRuntime]
$null = [Windows.Data.Pdf.PdfDocument,Windows.Data.Pdf,ContentType=WindowsRuntime]
$null = [Windows.Storage.Streams.InMemoryRandomAccessStream,Windows.Storage.Streams,ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder,Windows.Graphics.Imaging,ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.SoftwareBitmap,Windows.Graphics.Imaging,ContentType=WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine,Windows.Media.Ocr,ContentType=WindowsRuntime]
$null = [Windows.Media.Ocr.OcrResult,Windows.Media.Ocr,ContentType=WindowsRuntime]
$operationTask = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
} | Select-Object -First 1
$actionTask = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and -not $_.IsGenericMethod -and $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction'
} | Select-Object -First 1
function Await-Operation($Operation, [Type]$Type) {
    $task = $operationTask.MakeGenericMethod($Type).Invoke($null, @($Operation))
    $task.Wait()
    return $task.Result
}
function Await-Action($Action) {
    $task = $actionTask.Invoke($null, @($Action))
    $task.Wait()
}
$root = Split-Path $PSScriptRoot -Parent
$output = Join-Path $PSScriptRoot $EvidenceName
if (Test-Path -LiteralPath $output) { throw "Refusing overwrite: $output" }
$engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
if ($null -eq $engine) { throw 'Installed OCR engine unavailable' }
$results = @()
foreach ($file in Get-ChildItem -LiteralPath $root -Filter '*.pdf' -File | Sort-Object Name) {
    if ([int]$file.Name.Substring(0,2) -le 10) { continue }
    $storage = Await-Operation ([Windows.Storage.StorageFile]::GetFileFromPathAsync($file.FullName)) ([Windows.Storage.StorageFile])
    $pdf = Await-Operation ([Windows.Data.Pdf.PdfDocument]::LoadFromFileAsync($storage)) ([Windows.Data.Pdf.PdfDocument])
    if ($pdf.PageCount -lt 1) { throw "Empty PDF: $($file.Name)" }
    $sample = @(0,1,[int][Math]::Floor($pdf.PageCount/2),($pdf.PageCount-1)) | Sort-Object -Unique
    $ocrPages = @()
    for ($index=0; $index -lt $pdf.PageCount; $index++) {
        $page = $pdf.GetPage($index)
        if ($page.Size.Width -le 0 -or $page.Size.Height -le 0) { throw "Invalid page dimensions: $($file.Name) page $index" }
        if ($sample -contains $index) {
            $stream = New-Object Windows.Storage.Streams.InMemoryRandomAccessStream
            $options = New-Object Windows.Data.Pdf.PdfPageRenderOptions
            $options.DestinationWidth = 1600
            Await-Action ($page.RenderToStreamAsync($stream, $options))
            $decoder = Await-Operation ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
            $bitmap = Await-Operation ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
            $ocr = Await-Operation ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
            $ocrPages += [pscustomobject]@{physical_page=($index+1); text=$ocr.Text}
            $bitmap.Dispose()
            $stream.Dispose()
        }
        $page.Dispose()
    }
    $results += [pscustomobject]@{
        file=$file.Name; pages=$pdf.PageCount; bytes=$file.Length
        sha256=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        parser='Windows.Data.Pdf.PdfDocument'
        all_page_objects_opened=$true
        ocr_language=$engine.RecognizerLanguage.LanguageTag
        sampled_pages=$ocrPages
    }
    Write-Output "$($file.Name): $($pdf.PageCount) page objects; $($ocrPages.Count) rendered/OCR samples"
}
[IO.File]::WriteAllText($output,(ConvertTo-Json -InputObject @($results) -Depth 7),(New-Object Text.UTF8Encoding($false)))
