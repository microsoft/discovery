"""Join source receipts, manually checked bibliography and native PDF evidence."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


bibliography = load(HERE / "bibliography.json")
validation = {}
for evidence in sorted(HERE.glob("pdf-validation*.json")):
    for item in load(evidence):
        if item["file"] in validation:
            raise ValueError(f"Duplicate validation evidence: {item['file']}")
        validation[item["file"]] = (item, evidence.name)
receipts = [load(path) for path in sorted(HERE.glob("*-download.json"))]
successes = {item["file"]: item for item in receipts if item["status"] == "downloaded"}
entries = []
for citation in bibliography:
    filename = citation["file"]
    source = successes[filename]
    parsed, evidence = validation[filename]
    data = (ROOT / filename).read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if not (digest == source["sha256"] == parsed["sha256"]):
        raise ValueError(f"Hash mismatch: {filename}")
    if not (len(data) == source["bytes"] == parsed["bytes"]):
        raise ValueError(f"Byte count mismatch: {filename}")
    if not data.startswith(b"%PDF-") or b"%%EOF" not in data[-4096:]:
        raise ValueError(f"Invalid PDF envelope: {filename}")
    if parsed["pages"] < 1:
        raise ValueError(f"Invalid page count: {filename}")
    entries.append({
        **citation,
        "requested_url": source["url"],
        "resolved_url": source["resolved_url"],
        "metadata_url": source.get("metadata_url"),
        "source_host_basis": source["host_basis"],
        "retrieved_utc": source["retrieved_utc"],
        "http_status": source["http_status"],
        "content_type": source["content_type"],
        "bytes": len(data),
        "sha256": digest,
        "pages": parsed["pages"],
        "topics": source["topics"],
        "validation": {
            "pdf_header_and_eof": True,
            "native_parser": parsed["parser"],
            "first_page_rendered": True,
            "first_page_ocr_reviewed": True,
            "evidence": ".curation/" + evidence
        },
        "rights": "Public author/university/repository copy. No collection-wide open license or redistribution permission is asserted; retain each document's notices."
    })
actual = {path.name for path in ROOT.glob("*.pdf")}
if actual != {entry["file"] for entry in entries}:
    raise ValueError("Catalog does not match the complete local PDF collection")
manifest = {
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "directory": "knowledge/bs-data",
    "pdf_count": len(entries),
    "total_physical_pages": sum(item["pages"] for item in entries),
    "total_bytes": sum(item["bytes"] for item in entries),
    "scope": "Advanced RTL coding, static analysis/lint, functional simulation semantics and automated error localization. Not all documents are peer-reviewed research or dissertations.",
    "bookshelf_ingested": False,
    "documents": entries,
    "failed_download_attempts": [item for item in receipts if item["status"] != "downloaded"]
}
with (ROOT / "manifest.json").open("x", encoding="utf-8") as stream:
    json.dump(manifest, stream, indent=2)
print(json.dumps({key: manifest[key] for key in
                  ("pdf_count", "total_physical_pages", "total_bytes")}))
